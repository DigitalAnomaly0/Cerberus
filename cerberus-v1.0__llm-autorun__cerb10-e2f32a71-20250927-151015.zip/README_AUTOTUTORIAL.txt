Cerberus 1.0 — Auto-Run Tutorial Patch
Run ID: cerb10-80e8675c-20250927-150654

How to run:
- Windows: START_HERE.bat
- macOS/Linux: ./start_here.sh
- Any OS: python START_HERE.py

Outputs are written to artifacts/.
