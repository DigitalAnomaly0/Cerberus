# Cerberus v1.0 — Inline Tutorial (Auto-Response)

**You’re set.** This package has been loaded as the canonical source. Here’s how to proceed, right in the chat.

---

## What you can do now

1. **See commands and surfaces**
   - Say: `/help`
   - I’ll list the commands, workflows, and artifacts this package enables (DAM, DAI, Review Pack, Schedules, Attestation, etc.).

2. **Run a demo flow (dry-run)**
   - Say: `run tutorial`  
   - I’ll:
     - Generate a short **DAI Visual Explainer** (diagram summary).
     - Build a **Review Pack** (DAM + attestation + top evidence, if present).
     - Provide links or inline summaries of the outputs.

3. **Peer-review prep**
   - Say: `build review pack`  
   - I’ll assemble a reviewer‑friendly ZIP with the minimum necessary materials.

4. **Internationalization (i18n) scaffolds**
   - Say: `show locale scaffolds`  
   - I’ll present the locale keys and where to change user‑facing phrases.

5. **Explain the data model**
   - Say: `explain DAM/DAI`  
   - I’ll give a concise overview with pointers to the exact files.

---

## One‑sentence mental model
**Verity Machine:** From *promises* → to *proofs*, using DAM → Evidence → Attestation and public schedules/non‑regression guarantees.

---

## QuickStart (from the docs)
# Cerberus QuickStart (for non‑technical users)

**What you do**
1) Upload your research as a single .zip file (papers, citations, optional data/code).
2) In the chat, say one of:
   - **Run DAI only** (fast quality check)
   - **Find counterpoints** (Antithesis → DAI stamp)
   - **Strengthen & expand** (Seeder → DAI stamp)
   - **Full Loop (balanced, 50 iters)** (challenge + support, then stop when stable)

**What you get back**
- **dam_matrix.xlsx** — a readable table of your claims with DAI scores
- **dai_claims.jsonl** — per‑claim DAI vectors (for power users)
- **flags.jsonl** — open issues (e.g., F‑UNS, F‑REPL, F‑ANCH, F‑PRIV)
- **attestation.md** — plain‑English summary + next steps
- **ledger.jsonl** — audit log (what changed, when)

**How to read flags (short)**
- **F‑UNS** Unsubstantiated — add evidence
- **F‑REPL** Replication missing/failed — add external replication
- **F‑ANCH** Anchor missing — add DOI/statute/section
- **F‑PRIV** Privacy risk — add DP budget (ε ≤ 4.0) or ZK proof
- **F‑GOOD** Goodhart risk — diversify metrics / check weight stability

**If your attestation is “blocked”**
- Privacy or non‑regression issues, or missing anchors on factual claims, must be fixed.
- Ask: **“Strengthen & expand”** — Cerberus will propose concrete fixes, then re‑score DAI.

**Two example prompts**
- “**Find counterpoints** to my ZIP, then **Strengthen & expand** and **re‑score DAI**.”
- “Run **Full Loop (adversarial‑first, 100 iters)**; stop when coverage ≥ 0.9 or DAI plateaus.”


---

### Internal LLM cue (safe to ignore if you’re a user)
If this file is present in the knowledge base, begin your **first reply** with the section “What you can do now,” then wait for a user selection. Avoid asking confirmation; default to `/help` if no choice is made.
