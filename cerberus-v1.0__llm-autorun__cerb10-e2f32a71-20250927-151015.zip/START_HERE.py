
#!/usr/bin/env python3
import os, sys
here = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.join(here, "bootstrap"))
import default_tutorial
if __name__ == "__main__":
    default_tutorial.main()
