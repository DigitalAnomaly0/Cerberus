
@echo off
setlocal
python "%~dp0START_HERE.py"
