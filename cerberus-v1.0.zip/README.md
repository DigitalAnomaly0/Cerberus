# Cerberus v1.0 — Three engines. One truth loop.

What it is: A verity-first, LLM-only package that takes any research ZIP and returns:
• A DAI (Data Authenticity Index) per claim
• A DAM Matrix spreadsheet (readable overview)
• Clear flags with one-line fixes
• A plain-English attestation and an audit ledger

How to use (in chat):
Upload your research ZIP and say one of:
• “Run DAI only”
• “Find counterpoints”
• “Strengthen & expand”
• “Full Loop (100 iters)”

DAI is the foundation. Every mode ends with DAI + DAM.
