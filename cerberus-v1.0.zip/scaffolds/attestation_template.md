# Cerberus Attestation — {{RUN_ID}}

**Summary:** {{CLAIM_COUNT}} claims analyzed. {{FLAG_RED}} red / {{FLAG_YELLOW}} yellow flags open.
**DAI composite (median):** {{DAI_MEDIAN}} (Δ {{DAI_DELTA}} this run)

## Top Recommended Fixes
{{FIXES_LIST}}

## Blocking Issues
{{BLOCKERS_LIST}}  <!-- e.g., F-PRIV, F-NONR -->

_This attestation summarizes DAI status; red flags block “attested” status until resolved._
