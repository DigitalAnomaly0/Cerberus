# Cerberus · Progress Summary Renderer

Template: docs/Progress_Summary_Template.txt

Variables:
- RUN_ID
- CLAIM_N
- FLAG_N, FLAG_BREAKDOWN (e.g., "F-UNS 9, F-REPL 3, F-ANCH 2")
- CEX_N, CEX_BREAKDOWN (e.g., "3 causal, 2 predictive, 1 descriptive")
- COVERAGE (0.00–1.00), COVERAGE_TARGET (default 0.80)
- DAI_DELTA (signed float), DAI_MEDIAN_DELTA (median change)
- ATTEST_STATUS ("blocked"|"provisional"|"attested"|"draft")
- RED_COUNT
- TOP_FIXES (3–5 short bullets)

Rendering policy:
- Numbers rounded to 2 decimals.
- Keep list lengths bounded (≤5 entries).
- Always include coverage even if Antithesis not run (use 0.00).
