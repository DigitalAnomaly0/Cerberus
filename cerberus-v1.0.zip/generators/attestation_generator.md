# Cerberus · Attestation Generator (LLM-only)

Purpose: Render a plain-English attestation from current run artifacts.

Inputs:
- counts: CLAIM_COUNT, FLAG_RED, FLAG_YELLOW
- DAI: DAI_MEDIAN, DAI_DELTA (median delta this run)
- FIXES_LIST: one-liner fixes ordered by (severity desc, expected_uplift desc)
- BLOCKERS_LIST: list of blocking red flags (e.g., F-PRIV, F-NONR)

Template (scaffolds/attestation_template.md) variables:
- {{RUN_ID}}, {{CLAIM_COUNT}}, {{FLAG_RED}}, {{FLAG_YELLOW}}, {{DAI_MEDIAN}}, {{DAI_DELTA}}, {{FIXES_LIST}}, {{BLOCKERS_LIST}}

Selection policy for FIXES_LIST:
1) Sort open flags by severity (red > yellow) then axis importance (replicability, privacy, anchor, evidence_quality, conflict, provenance, ledger_integrity, attestation).
2) Group by claim_id; keep max 1 fix per claim for top 5 entries.
3) Convert to imperative phrases (e.g., "Add external replication", "Provide DP budget (ε≤4.0)", "Add DOI/statute anchor").

Blocking rules:
- If any F-PRIV or F-NONR red → attestation status = "blocked".
- If any factual claim (descriptive/causal) has F-ANCH red → "blocked".
- Else if any red remains → "provisional".
- Else → "attested".

Determinism:
- Use fixed sort keys; tie-break by claim_id asc; render markdown verbatim.
