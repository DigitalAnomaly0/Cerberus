# Review Pack — cerberus-dai-20250927-0812-CD1A

This pack contains the essentials for peer review:
- dam_matrix.xlsx
- attestation.md
- 2 evidence manifests (C-001 replication plan, C-003 privacy plan)

Selection policy: rank by severity (red first, then yellow) and lowest DAI composite.
For this mini-run, all flags are yellow and no counterexamples were found.
