# Governor Demo — cerberus-dai-20250927-0812-CD1A

Role: Compute DAI, open flags, and emit DAM + attestation + ledger.
Result: DAI vectors and flags produced deterministically from claimcards; no Antithesis/Seeder applied.
