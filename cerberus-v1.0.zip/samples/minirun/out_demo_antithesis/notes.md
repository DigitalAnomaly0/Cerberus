# Antithesis Demo — cerberus-ant-20250927-0812-CD1A

Role: Attack claims; produce challenge results and minimal counterexamples.
Result: GOODHART counterexample refuted C-002; Governor re-scored DAI and opened F-GOOD.
