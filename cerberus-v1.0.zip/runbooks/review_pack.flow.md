# Runbook — Review Pack

1) Read flags + DAI; rank claims by severity↓ then composite↑.
2) Select top-N evidence packs (distinct claim_ids) per spec.
3) Create `review_pack/` with:
   - dam_matrix.xlsx
   - attestation.md
   - evidence_packs/EP-*.json
   - COVER.md (what reviewers should read first)
4) Zip as `<RUN_ID>-REVIEW-PACK.zip` and present link.
