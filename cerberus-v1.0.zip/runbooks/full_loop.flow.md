# Runbook — Full Loop

1) Governor: initial DAI + DAM.
2) Repeat (bounded by max_iter, early-stop):
   a) Antithesis batch → Governor re-score
   b) Seeder batch → Governor re-score
   c) Check early-stop: plateau (Δ<ε), no-new-counterexamples, or coverage target met.
3) Final Governor stamp → package + Progress Summary → wipe workspace.
