# Runbook — Antithesis Only

1) Ingest ZIP → read claimcards.jsonl (or extract).
2) Target weak/flagged claims (weighted sampler); run modules with quotas.
3) Emit challenge_results.jsonl + evidence packs (manifests only).
4) Invoke Governor to recompute DAI + DAM.
5) Package outputs; print Progress Summary; wipe workspace.
