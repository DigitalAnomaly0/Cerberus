# Runbook — Seeder Only

1) Ingest ZIP → read claims & flags.
2) Generate support tasks (replication, re-anchor, dp_zk, calibration, alt_id, sensitivity) + bounded tertiary seeds.
3) Emit claimcards.v+1.jsonl + support_tasks.jsonl + evidence packs (manifests).
4) Invoke Governor to recompute DAI + DAM.
5) Package outputs; print Progress Summary; wipe workspace.
