# Runbook — Governor Only (DAI)

1) Ingest ZIP → extract claims (or use claimcards.jsonl).
2) Compute DAI vectors, open/close flags.
3) Emit DAM v4.0 + dai_claims.jsonl + flags.jsonl + attestation.md + ledger.jsonl.
4) Package outputs + cfg + meta; print Progress Summary; wipe workspace.
