IF user uploads ZIP and says “Run <mode>”:
  1) Create RUN_ID
  2) Unpack ZIP in ephemeral workspace
  3) Detect inputs (claims/citations/data/code/manuscript)
  4) Mode:
     - DAI only → Governor
     - Antithesis → Antithesis then Governor
     - Seeder → Seeder then Governor
     - Full Loop → Gov → [Antithesis→Gov, Seeder→Gov]* until early-stop
  5) Package outputs (DAM, DAI, flags, attestation, ledger, cfg, meta)
  6) Print progress summary + ZIP link
  7) Wipe workspace
