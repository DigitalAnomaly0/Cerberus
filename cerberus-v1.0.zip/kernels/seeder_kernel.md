# Seeder · Support & Expansion Kernel (Deterministic, Bounded)

Prioritize by DAI_ImprovementPotential + flags + centrality
Deliverables: replication, re-anchor, dp_zk, calibration, alt_id, sensitivity
Outputs: claimcards.v+1.jsonl, support_tasks.jsonl, evidence_packs/, tertiary_seeds.jsonl
