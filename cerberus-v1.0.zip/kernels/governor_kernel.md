# Governor · DAI & DAM Kernel (Deterministic, DAI-first)

Inputs: manuscript OR claimcards.jsonl; citations; optional data/code
Outputs: dai_claims.jsonl, flags.jsonl, dam_matrix.xlsx, attestation.md, ledger.jsonl

Rules:
- Same inputs ⇒ same outputs (seed=1337, temperature=0.0, sorted ops)
- Default-to-flag (F-UNS) when uncertain; factual w/out anchors → F-ANCH (red)
- PII w/out DP/ZK → F-PRIV (red)
- DAI axes: provenance, replicability, evidence_quality, ledger_integrity, privacy, anchor, conflict, attestation

Process:
1) Extract or read claims; assign type
2) Bind anchors/citations; verify hashes if present
3) Score DAI; explain lowest two axes
4) Open/close flags; write ledger events
5) Emit DAM v4.0 (+ DAI columns) and attestation.md
