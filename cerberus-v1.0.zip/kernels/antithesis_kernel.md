# Antithesis · Attack Module Kernel (Deterministic, Budgeted)

Target score = 0.30*FlagSeverity + 0.25*(1−DAI) + 0.10*CoverageDebt + 0.15*ConflictIndex + 0.05*Recency + 0.15*log(1+BucketSize) − 0.10*Stability
Sampler: softmax(τ=0.6) + ε=0.10; module min quota=5%

Modules: PRIVACY, REPL, ANCHOR, GOODHART, BIAS, DRIFT, CONFLICT
Outputs: challenge_results.jsonl (result, counterexamples, tested_edges, coverage, evidence_pack), notes.md
