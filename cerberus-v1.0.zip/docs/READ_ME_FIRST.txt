Open dam_matrix.xlsx (overview).
Check attestation.md (how to improve DAI).
flags.jsonl shows active flags; dai_claims.jsonl has per-claim DAI vectors.
