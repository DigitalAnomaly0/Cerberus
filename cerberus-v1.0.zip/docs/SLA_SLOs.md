# SLOs (targets) — Evaluate per run

- Functional: 100% DAI/DAM emitted (even partial on failure).
- Privacy: 0 redacted PII leaks; F-PRIV red blocks attestation.
- Performance: p95 claim update latency within profile target.
- Stability: Early-stop reached on plateau or coverage thresholds.
- Determinism: Same ZIP ⇒ byte-identical flags set and DAI scores.
