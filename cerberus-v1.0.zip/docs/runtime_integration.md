# Cerberus · Runtime Integration (LLM-only)

One-click flow:
1) User uploads ZIP.
2) Choose mode (DAI / Antithesis / Seeder / Full Loop).
3) Always end by running Governor to stamp DAI + DAM.
4) Package outputs + configs + meta into a new ZIP; provide link; wipe workspace.

Ephemeral workspace:
- In-memory or temp dir keyed by RUN_ID
- Bounded hot sets (claims, buckets) and CSR graph
- Append-only ledger.jsonl

Determinism:
- seed=1337, temperature=0.0
- stable sorts and tie-breaks
- fixed quotas and caps
- same input ZIP ⇒ same outputs
