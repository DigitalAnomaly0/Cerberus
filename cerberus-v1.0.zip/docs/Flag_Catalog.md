# Flag Catalog (v1)

- F-UNS — Unsubstantiated
- F-REPL — Replication missing/failed
- F-ANCH — Anchor missing/misaligned
- F-PRIV — Privacy risk (DP/ZK missing)
- F-GOOD — Goodhart risk (metric gaming)
- F-BIAS — Fairness/bias issue
- F-DRFT — Model/metric drift
- F-CONF — Contradiction with other claim
- F-NONR — Non-regression risk (policy floor drop)
