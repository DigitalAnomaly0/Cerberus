# Cerberus QuickStart (for non‑technical users)

**What you do**
1) Upload your research as a single .zip file (papers, citations, optional data/code).
2) In the chat, say one of:
   - **Run DAI only** (fast quality check)
   - **Find counterpoints** (Antithesis → DAI stamp)
   - **Strengthen & expand** (Seeder → DAI stamp)
   - **Full Loop (balanced, 50 iters)** (challenge + support, then stop when stable)

**What you get back**
- **dam_matrix.xlsx** — a readable table of your claims with DAI scores
- **dai_claims.jsonl** — per‑claim DAI vectors (for power users)
- **flags.jsonl** — open issues (e.g., F‑UNS, F‑REPL, F‑ANCH, F‑PRIV)
- **attestation.md** — plain‑English summary + next steps
- **ledger.jsonl** — audit log (what changed, when)

**How to read flags (short)**
- **F‑UNS** Unsubstantiated — add evidence
- **F‑REPL** Replication missing/failed — add external replication
- **F‑ANCH** Anchor missing — add DOI/statute/section
- **F‑PRIV** Privacy risk — add DP budget (ε ≤ 4.0) or ZK proof
- **F‑GOOD** Goodhart risk — diversify metrics / check weight stability

**If your attestation is “blocked”**
- Privacy or non‑regression issues, or missing anchors on factual claims, must be fixed.
- Ask: **“Strengthen & expand”** — Cerberus will propose concrete fixes, then re‑score DAI.

**Two example prompts**
- “**Find counterpoints** to my ZIP, then **Strengthen & expand** and **re‑score DAI**.”
- “Run **Full Loop (adversarial‑first, 100 iters)**; stop when coverage ≥ 0.9 or DAI plateaus.”
