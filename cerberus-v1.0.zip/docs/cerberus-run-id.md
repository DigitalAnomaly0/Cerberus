# Cerberus Run‑ID Convention

Pattern: `cerberus-<mode>-<YYYYMMDD>-<HHMM>-<RID>`

- **mode**: `dai` | `antithesis` | `seeder` | `fullloop`
- **YYYYMMDD-HHMM**: run timestamp (local to operator)
- **RID**: deterministic 4–6 char suffix derived from the input ZIP

## RID generation (deterministic & collision‑aware)

1) Compute `H = SHA256(bytes_of_zip || b":1337")`  
2) Encode the first 25 bits of `H` in **Crockford Base32**, uppercase, no padding.
3) Truncate to 4 chars → this is the default **RID**.  
4) If a collision is detected for the same timestamp window, extend to 6 chars.

**Properties**
- Same ZIP ⇒ same RID (independent of time and mode).
- Different ZIPs almost surely get different RIDs.
- The timestamp keeps runs human‑sortable; the RID helps you spot duplicates.

**Examples**
- `cerberus-dai-20250115-1030-AB7Q`
- `cerberus-fullloop-20250302-1942-ZK1M`
