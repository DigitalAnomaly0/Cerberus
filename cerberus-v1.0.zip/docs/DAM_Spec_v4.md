# DAM v4.0 (with DAI extensions)

Columns:
DAM_ID, Location, Key, Text_Segment, Core_Claim, Claim_Type,
Legislative_Anchor(s), Primary_Evidence, Evidence_Type,
Evidence_Quality, Verification_Status, Substantiation_Status,
Flag_Codes, Flag_Severity, DAI_Vector, DAI_Composite,
Attestation_Status, Hash_Pointer, Notes
