# Changelog

## 1.0-skeleton (2025-09-27)
- Initial Cerberus package with schemas, configs, kernels, runbooks.
- Added generators, presets, sample mini-run, and acceptance harness.
- Added QuickStart, Run-ID guide, FAQ, Troubleshooting.
- Added Outputs Glossary, Reviewer Checklist, Prompt Bank, Remediation Cookbook.
- Added bounded profiles, interoperability notes, PII/citation/claim macros.
- Added SLOs, metrics schema, artifact naming.
