# Outputs Glossary

- **dam_matrix.xlsx** — Human-readable matrix of claims with DAI and flags.
- **dai_claims.jsonl** — One JSON per line with per-claim DAI vectors and explanations.
- **flags.jsonl** — Open flags per claim with severity and rationale.
- **attestation.md** — Plain-English summary, fixes, and attestation status.
- **ledger.jsonl** — Append-only audit events.
- **meta.json** — Determinism seed, input hashes, engine versions.
- **cfg/** — Effective configs used in the run.
- **evidence_packs/** — Manifests of supporting/attacking evidence (hash-referenced).
- **challenge_results.jsonl** — Antithesis module outputs (result/coverage/counterexamples).
- **support_tasks.jsonl** — Seeder actions with expected DAI uplift.
