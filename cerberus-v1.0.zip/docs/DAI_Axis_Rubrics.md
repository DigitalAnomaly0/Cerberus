# DAI Axis Rubrics (v1)

- provenance: 1.0 signatures/hashes; 0.6 partial; 0.2 none
- replicability: 1.0 external; 0.6 internal only; ≤0.4 none/failed
- evidence_quality: ≥0.8 primary & rigorous; 0.5 secondary/unclear; ≤0.3 hearsay
- ledger_integrity: 1.0 hash pointers + monotonic log; 0.7 partial; 0.3 none
- privacy: ≥0.9 DP/ZK proven; 0.5 unclear risk; 0.0 re-ID risk (+ F-PRIV red)
- anchor: 1.0 strong DOI/statute; 0.6 weak; 0.0 missing (+ F-ANCH)
- conflict: ≥0.8 none; 0.5 tension; ≤0.3 contradiction (+ F-CONF)
- attestation: ≥0.9 independent validator; 0.6 self; 0.3 none
