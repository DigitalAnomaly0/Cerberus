# Reviewer Checklist (printable)

☐ DAM rows match manuscript claims (spot-check 3–5 rows)  
☐ All factual claims have anchors (no F-ANCH red)  
☐ Causal claims: replication and identification clear (no F-REPL red)  
☐ Privacy: DP budget or ZK proof present if personal data (no F-PRIV red)  
☐ Goodhart risk addressed (alternative metrics/sensitivity available)  
☐ Bias tests present for predictive models (no F-BIAS red)  
☐ Drift/calibration checked for deployed models (F-DRFT clear)  
☐ No contradictions among related claims (F-CONF clear)  
☐ Attestation status: “attested” or “provisional” with clear next steps
