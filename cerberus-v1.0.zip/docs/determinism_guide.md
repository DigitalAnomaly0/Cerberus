# Cerberus · Determinism & Bounds

- Do not depend on unordered dict iteration.
- Sort claims by (claim_id asc) before batching.
- Cap hot sets (H claims, B buckets); evict by priority (uncertainty+centrality+novelty − stability).
- Recompute DAI axes only when dependencies change.
- Record seed and input hashes in meta.json.
