# Artifact Naming

- Run ZIP: `cerberus-<mode>-<YYYYMMDD>-<HHMM>-<RID>.zip`
- Evidence pack manifests: `evidence_packs/EP-<claim_id>-<nn>.json`
- Challenge results: `challenge_results.jsonl`
- Support tasks: `support_tasks.jsonl`
- Logs/ledger: `ledger.jsonl`
