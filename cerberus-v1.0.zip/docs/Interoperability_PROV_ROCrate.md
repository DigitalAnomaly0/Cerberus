# Interoperability: W3C PROV & RO-Crate

- Map `ledger.jsonl` events to **W3C PROV** (`prov:Entity`, `prov:Activity`, `prov:Agent`).  
- Treat `dam_matrix.xlsx` and `dai_claims.jsonl` as RO-Crate entries with checksums.  
- Add `prov:wasGeneratedBy` from outputs to the RUN_ID activity; `prov:used` for input ZIP.  
- Optional: create a `ro-crate-metadata.json` (future extension).
