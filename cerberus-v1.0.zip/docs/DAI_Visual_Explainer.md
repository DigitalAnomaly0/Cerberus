# DAI Visual Explainer

![DAI diagram](figures/dai_explainer.svg)

**DAI axes (0–1):** provenance, replicability, evidence_quality, ledger_integrity, privacy, anchor, conflict, attestation.  
**Composite:** weighted sum (see `cfg/dai.config.yaml`).  
**Flags:** map to axes (e.g., F-REPL → replicability). Red flags block attestation.

## Three mini examples

**Example A — Causal claim w/out replication**  
Vector: provenance 0.7, replicability 0.4, evidence_quality 0.6, ledger 1.0, privacy 1.0, anchor 1.0, conflict 0.8, attestation 0.6 → composite ≈ 0.76.  
Flags: F-REPL (yellow), F-UNS (yellow). Fix: external replication + clarify ID.

**Example B — Descriptive Goodhart risk**  
Vector: similar to 0.80 composite but **Goodhart probe opens F-GOOD (yellow)**.  
Fix: add multi-metric dashboard, weight-stability report.

**Example C — Privacy budget missing**  
Vector: privacy 0.6 due to missing ε → composite ≈ 0.76.  
Flag: F-PRIV (yellow/red depending on risk). Fix: add DP budget (ε ≤ 4.0) or ZK eligibility proof.
