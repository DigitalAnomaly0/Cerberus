# Flag Remediation Cookbook

- **F-PRIV**: Provide DP budget (ε ≤ 4.0) or ZK eligibility proof; avoid PII in outputs.
- **F-ANCH**: Add precise DOI/statute/section; include page/paragraph if applicable.
- **F-REPL**: Add external replication or preregistered internal replication; share code path.
- **F-UNS**: Provide primary data or strong secondary chain; link to evidence pack.
- **F-GOOD**: Add robustness checks; multi-metric dashboard; weight-stability report.
- **F-BIAS**: Adjust thresholds; reweight data; calibration; report group & individual fairness.
- **F-DRFT**: Recalibrate; monitor drift; retrain; document distributional changes.
- **F-CONF**: Resolve contradictions; constrain scope; pick one canonical claim.
- **F-NONR**: (optional policy) Provide proof no protected floor regresses.
