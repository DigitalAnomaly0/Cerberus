# Cerberus · Security & Privacy

- Never emit PII beyond what user provided.
- Personal data requires DP budget (ε≤4.0) or ZK eligibility proof → else F-PRIV (red).
- Non-regression (if enabled) blocks outputs that reduce protected floors.
- Red flags (F-PRIV, F-NONR, F-ANCH on factual) block attestation.
