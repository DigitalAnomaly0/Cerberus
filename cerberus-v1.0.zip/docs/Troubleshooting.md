# Cerberus Troubleshooting

## 1) “No claims found”
**Why:** The manuscript is too unstructured or scanned.  
**Fix:** Upload a clearer text/PDF or include `claimcards.jsonl`.  
**Run:** “Run DAI only” — Cerberus will produce a stub DAM with F-UNS/F-ANCH and show how to improve extraction.

## 2) “Attestation: BLOCKED (F-PRIV red)”
**Why:** Personal data used without DP budget or ZK eligibility proof.  
**Fix:** Add a DP budget (ε ≤ 4.0) or a ZK eligibility proof statement.  
**Run:** “Strengthen & expand” → Governor re-score DAI → attestation should move to provisional/attested once resolved.

## 3) “F-ANCH red on factual claims”
**Why:** Missing DOI/statute/section.  
**Fix:** Provide a precise anchor string (e.g., DOI:10.xxxx/…, Statute §…).  
**Run:** “Strengthen & expand” (re-anchor deliverable) → “Run DAI only”.

## 4) “F-REPL / F-UNS won’t clear on causal claims”
**Why:** No external replication or unclear identification.  
**Fix:** Add an external replication OR specify an identification strategy (IV/DiD/RDD).  
**Run:** “Strengthen & expand” (replication + alt_id) → “Run DAI only”.

## 5) “F-GOOD — Goodhart risk”
**Why:** Single fragile metric; results flip under small weight changes.  
**Fix:** Add a dual-track evaluation or robustness checks.  
**Run:** “Find counterpoints” (GOODHART module) to verify; then “Strengthen & expand” to diversify metrics.

## 6) “F-BIAS — fairness issue”
**Why:** Group/individual fairness bounds exceeded.  
**Fix:** Rebalance dataset, adjust thresholds, or add calibration.  
**Run:** “Find counterpoints” (BIAS) → “Strengthen & expand” (calibration).

## 7) “F-DRFT — drift or calibration off”
**Why:** Deployment data differ from training, or miscalibrated predictions.  
**Fix:** Recalibrate; monitor drift; retrain if necessary.  
**Run:** “Strengthen & expand” (calibration) then “Run DAI only”.

## 8) “F-CONF — contradiction detected”
**Why:** Conflicting claims in the same network.  
**Fix:** Resolve inconsistency; keep one claim or reconcile scope.  
**Run:** “Full Loop (adversarial-first, 50 iters)” to converge, or resolve manually and rerun DAI.

## 9) “Outputs look different between runs”
**Why:** Inputs changed or nondeterministic settings.  
**Fix:** Keep the ZIP identical, and ensure seed=1337, temperature=0.0.  
**Run:** “Run DAI only” and compare `meta.json` seeds/hashes.

## 10) “Too many flags; where do I start?”
**Tip order:** Privacy → Anchors → Replication → Goodhart → Bias → Drift → Conflict.  
**Run:** “Strengthen & expand” and follow the top 3 one-line fixes in the attestation. Then rerun DAI.

---

### Common Commands
- **Run DAI only** — fast verity snapshot  
- **Find counterpoints** — hunt minimal counterexamples  
- **Strengthen & expand** — targeted support + tertiary seeds  
- **Full Loop (balanced, 100 iters)** — iterative challenge/support with early-stop

**Remember:** DAI is the foundation. Every run ends with DAI + DAM.
