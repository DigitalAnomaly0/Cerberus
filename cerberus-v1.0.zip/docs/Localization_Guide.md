# Localization Guide

- Edit or add `locales/<lang>.json` (e.g., es, de, fr, pt-BR).
- Keep keys stable; add new UI strings as needed.
- Set default/fallback in `locales/locale_manifest.json`.
- Users can switch with `/locale <lang>`.
