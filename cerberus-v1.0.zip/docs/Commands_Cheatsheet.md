# Cerberus Commands Cheatsheet

**Core**
- Run DAI only
- Find counterpoints
- Strengthen & expand
- Full Loop (balanced|adversarial-first|coverage-first, N iters)

**Toggles**
- /preset academic_general | ml_experiments | balanced | adversarial-first | coverage-first
- /profile small | medium | large
- /iters N
- /locale xx or xx-YY

**Inspect**
- /flags | /dam | /attestation | /progress | /export

**Focus**
- /focus C-001 | /evidence C-001

**Meta**
- /help | /commands | /about | /version
