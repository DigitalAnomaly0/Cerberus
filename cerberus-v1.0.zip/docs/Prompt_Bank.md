# Prompt Bank (copy/paste)

• Run DAI only  
• Find counterpoints  
• Strengthen & expand  
• Full Loop (balanced, 100 iters)  
• Full Loop (adversarial-first, 75 iters)  
• Full Loop (coverage-first, 120 iters)  
• Re-score DAI  
• Export results again
