# Cerberus FAQ

**Q: What is Cerberus?**  
A verity-first, LLM-only package with three engines (Seeder, Antithesis, Governor) that takes a research ZIP and returns DAI scores, a DAM Matrix, flags, attestation, and an audit ledger.

**Q: Do I need to install anything?**  
No. Upload a single ZIP and tell the LLM what mode to run. That's it.

**Q: What modes should I try first?**  
- **Run DAI only** for a quick quality check.  
- **Find counterpoints** to stress-test claims.  
- **Strengthen & expand** to raise DAI by adding support.  
- **Full Loop (balanced, N iters)** for iterative challenge + support.

**Q: What is DAI?**  
The Data Authenticity Index, an 8-axis vector per claim (provenance, replicability, evidence_quality, ledger_integrity, privacy, anchor, conflict, attestation) plus a composite score.

**Q: What is the DAM Matrix?**  
A spreadsheet that summarizes each claim, anchors, evidence, flags, and DAI. It’s reader-friendly for committees and reviewers.

**Q: Why am I seeing flags like F-UNS or F-REPL?**  
Flags point to verity gaps: Unsubstantiated (F-UNS), Replication (F-REPL), Anchor (F-ANCH), Privacy (F-PRIV), Goodhart (F-GOOD), Bias (F-BIAS), Drift (F-DRFT), Conflict (F-CONF). Red blocks attestation; yellow asks for improvement.

**Q: Can I run the engines separately?**  
Yes. Each mode ends by stamping DAI + DAM with the Governor.

**Q: Will my files be modified?**  
No. Cerberus works in an ephemeral workspace and returns outputs in a downloadable ZIP.

**Q: Is Non-Regression enforced?**  
Off by default. If enabled, outputs that reduce protected floors trigger F-NONR (red). Keep it off unless your domain needs it.

**Q: How do run IDs work?**  
See `docs/cerberus-run-id.md`. Same ZIP ⇒ same RID suffix; human-sortable timestamps.
