Gov-DAI-01: PDF with 5 claims; 1 causal missing replication → F-UNS & F-REPL; DAM/DAI emitted.
Ant-02: GOODHART risk corpus → ≥1 refuted or coverage ≥0.5; DAI updated; possibly F-GOOD.
See-03: F-ANCH + F-REPL → Seeder emits re-anchor + replication; flag downgrade or DAI ↑.
Priv-04: Personal data without DP/ZK → F-PRIV (red); attestation blocked.
Loop-05: Full loop (max_iter=50) → early-stop triggers; memory steady after hot-set saturation.
