# Acceptance Harness (LLM-only)

Say: “Run Harness” — then execute:

For each test:
1) Load samples or user-provided corpus as needed.
2) Run the specified mode with deterministic settings (seed=1337).
3) Compare produced flags/DAI/DAM to expectations:
   - Gov-DAI-01: expect F-UNS & F-REPL on causal claim w/out replication.
   - Ant-02: expect ≥1 refuted or coverage ≥0.5.
   - See-03: expect flag downgrade or DAI composite increase.
   - Priv-04: expect F-PRIV(red) + attestation blocked.
   - Loop-05: expect early-stop; stable memory after hot-set saturation.
4) Summarize pass/fail and print the Progress Summary.
