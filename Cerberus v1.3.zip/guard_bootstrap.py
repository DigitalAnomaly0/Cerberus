
# guard_bootstrap.py - Cerberus v1.3 enforcement bootstrap (self-contained)
import os, re, sys, json, pathlib, shutil
from typing import List, Tuple

DEFAULT_PATTERNS = {
    "email": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
    "phone": r"\b(?:\+?1[-.\s]?)?(?:\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}\b",
    "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
    "address_like": r"\b\d{1,6}\s+[A-Za-z0-9.\- ]+\s+(?:St|Street|Rd|Road|Ave|Avenue|Blvd|Boulevard|Ln|Lane|Dr|Drive)\b",
}

def load_guard_config(config_path: str) -> dict:
    try:
        import yaml
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}

def compile_patterns(guard_cfg: dict):
    pats = dict(DEFAULT_PATTERNS)
    try:
        user = guard_cfg.get("patterns", {})
        for k,v in (user or {}).items():
            if isinstance(v, str) and v.strip():
                pats[k] = v
    except Exception:
        pass
    return {k: re.compile(v, re.IGNORECASE|re.MULTILINE) for k,v in pats.items()}

def scan_text(text: str, re_map) -> List[Tuple[str,Tuple[int,int]]]:
    findings = []
    for name, rx in re_map.items():
        for m in rx.finditer(text):
            findings.append((name, m.span()))
    return findings

def pii_zero_enforce(output_root: str, guard_cfg_path: str, redact_logs: bool=True) -> dict:
    guard = load_guard_config(guard_cfg_path)
    re_map = compile_patterns(guard)
    report = {"scanned_files": 0, "redacted": 0, "violations": []}
    root = pathlib.Path(output_root)
    if not root.exists():
        return report
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in (".txt",".md",".json",".csv",".log",".html",".xml",".yml",".yaml"):
            try:
                txt = p.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            hits = scan_text(txt, re_map)
            if hits:
                report["scanned_files"] += 1
                report["violations"].append({"file": str(p), "count": len(hits)})
                if redact_logs:
                    red = txt
                    for name, rx in re_map.items():
                        red = rx.sub(f"[REDACTED_{name.upper()}]", red)
                    p.write_text(red, encoding="utf-8")
                    report["redacted"] += 1
            else:
                report["scanned_files"] += 1
    # Write a machine-readable enforcement report
    (root/"_enforcement_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report

def fail_closed_if_needed(success: bool, report: dict, gate: bool=True):
    if not gate:
        return
    if not success:
        sys.exit(2)
    # If any violations remain (should be redacted), treat as fail-closed
    outstanding = sum(v.get("count",0) for v in report.get("violations", []))
    if outstanding > 0:
        sys.exit(3)

def apply_governor_env():
    # Read governor policy if present for toggles (best-effort)
    gov = {}
    for p in ("governor_policy.yaml", "config/governor_policy.yaml", "guard/governor_policy.yaml"):
        if os.path.exists(p):
            try:
                import yaml
                gov = yaml.safe_load(open(p,"r",encoding="utf-8"))
                break
            except Exception:
                pass
    modes = (gov or {}).get("modes", {}) or {}
    # Surface toggles as env for the engine
    os.environ.setdefault("CERB_FAIL_CLOSED", "1" if modes.get("fail_closed", True) else "0")
    os.environ.setdefault("CERB_STRICT_SYNTHETIC", "1" if modes.get("strict_dataset_alias", True) else "0")
    os.environ.setdefault("CERB_PII_ZERO_GATE", "1" if modes.get("pii_zero_gate", True) else "0")
    return modes

def post_run_enforce(output_dir: str):
    cfg_candidates = [
        "guard_config.yaml",
        "config/guard_config.yaml",
        "guard/guard_config.yaml"
    ]
    cfg = next((p for p in cfg_candidates if os.path.exists(p)), None)
    report = pii_zero_enforce(output_dir, cfg or "", redact_logs=True)
    fail_closed_if_needed(True, report, gate=os.environ.get("CERB_FAIL_CLOSED","1")=="1")
    return report
