# emit_report.py — Cerberus v1.3 emitter (adds 4a–4c)
import os, re, json, io, base64, zipfile, math
from datetime import datetime, timezone
import pandas as pd

DEFAULT_BANNED = [
    r"Right to Live", r"Verity Machine", r"UNT(?!\w)", r"Sam\s+Knupp", r"University of North Texas",
    r"Amendment\s+\d+", r"Act\s+Title\s+[IVX]+", r"Concentra", r"Wise Health System"
]

def load_scrub_list(root):
    for cand in ("dummy_scrub.yaml","config/dummy_scrub.yaml","../dummy_scrub.yaml"):
        p = os.path.join(root, cand)
        if os.path.exists(p):
            try:
                import yaml
                data = yaml.safe_load(open(p,"r",encoding="utf-8"))
                if isinstance(data, list) and all(isinstance(x, str) for x in data):
                    return data
            except Exception:
                pass
    return DEFAULT_BANNED

def _scrub_str(text: str, patterns):
    if not isinstance(text, str):
        return text
    s = text
    for pat in patterns:
        s = re.sub(pat, "[DUMMY_TEXT]", s, flags=re.IGNORECASE)
    return s

def read_csv(path):
    try:
        return pd.read_csv(path)
    except Exception:
        return None

def to_records(df, scrub_patterns):
    if df is None:
        return None
    out = []
    for _, row in df.iterrows():
        rec = {}
        for c, v in row.items():
            if isinstance(v, str):
                rec[c] = _scrub_str(v, scrub_patterns)
            else:
                rec[c] = v if pd.notna(v) else None
        out.append(rec)
    return out

def encode_data_url(path, mime="text/csv"):
    try:
        with open(path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        name = os.path.basename(path)
        return f"data:{mime};base64,{b64}", name
    except Exception:
        return None, None

def shewhart_stats(vals):
    xs = [v for v in vals if v is not None and not (isinstance(v,float) and math.isnan(v))]
    if not xs:
        return {"mean": None, "sigma": None, "ucl": None, "lcl": None, "breaches": 0}
    mean = sum(xs)/len(xs)
    var = sum((x-mean)**2 for x in xs)/len(xs)
    sigma = math.sqrt(var)
    u = mean + 3*sigma; l = mean - 3*sigma
    breaches = sum(1 for v in xs if (v>u or v<l))
    return {"mean": mean, "sigma": sigma, "ucl": u, "lcl": l, "breaches": breaches}

def run_rules(vals):
    xs = [v for v in vals if v is not None and not (isinstance(v,float) and math.isnan(v))]
    if not xs: return {"breaches":0, "reasons":[]}
    m = sum(xs)/len(xs)
    var = sum((x-m)**2 for x in xs)/len(xs) or 1e-9
    s = math.sqrt(var)
    hi2, lo2 = m + 2*s, m - 2*s
    reasons=[]; two3=0; eight=0
    # 2 of 3 beyond ±2σ
    for i in range(0, len(xs)-2):
        w = xs[i:i+3]
        hi = sum(1 for v in w if v>hi2); lo = sum(1 for v in w if v<lo2)
        if hi>=2 or lo>=2: two3+=1; reasons.append(f"Rule: 2-of-3 beyond ±2σ @ window {i+1}-{i+3}")
    # 8 in a row on one side
    cnt=0; side=None
    for i,v in enumerate(xs):
        cur = 'H' if v>=m else 'L'
        if side is None or cur==side: cnt+=1
        else: cnt=1; side=cur
        side = cur if side is None else side
        if cnt>=8: eight+=1; reasons.append(f"Rule: 8-in-a-row on {'high' if side=='H' else 'low'} side starting @ index {i-cnt+2}"); cnt=0; side=None
    return {"breaches": two3+eight, "reasons": reasons}

def ewma_last(vals, alpha=0.2):
    y=None
    for v in vals:
        if v is None or (isinstance(v,float) and math.isnan(v)): continue
        y = v if y is None else alpha*v + (1-alpha)*y
    return y

def corr(xs, ys):
    x = [v for v in xs if v is not None]
    y = [v for v in ys if v is not None]
    n = min(len(x), len(y))
    if n < 2: return None
    x, y = x[:n], y[:n]
    mx = sum(x)/n; my = sum(y)/n
    num = sum((x[i]-mx)*(y[i]-my) for i in range(n))
    dx = sum((x[i]-mx)**2 for i in range(n))
    dy = sum((y[i]-my)**2 for i in range(n))
    return (num / math.sqrt(dx*dy)) if dx*dy>0 else None

def compute_analysis(embed_data):
    D = embed_data or {}
    it = D.get("iterations") or []
    # series
    iters = [int(r.get("iter") or 0) for r in it]
    acc = []
    dai = []
    rpr = []
    tokens = []
    for r in it:
        a = r.get("Acceptance")
        if a is None and r.get("resolutions_attempted"):
            try:
                a = ( (r.get("resolutions_accepted") or 0) / r.get("resolutions_attempted") ) * 100.0
            except Exception:
                a = None
        acc.append(a)
        dai.append(r.get("DAI_score"))
        rpr.append(r.get("RPR_percent"))
        tokens.append( (r.get("tokens_in_iter") or 0) + (r.get("tokens_out_iter") or 0) if (r.get("tokens_in_iter") is not None or r.get("tokens_out_iter") is not None) else None )

    sh = {
        "accept": shewhart_stats(acc),
        "dai": shewhart_stats(dai),
        "rpr": shewhart_stats(rpr),
    }
    rr = {
        "accept": run_rules(acc),
        "dai": run_rules(dai),
        "rpr": run_rules(rpr),
    }
    ew = {
        "accept": ewma_last(acc),
        "dai": ewma_last(dai),
        "rpr": ewma_last(rpr),
    }
    cat = D.get("category_counts")
    if not cat and it:
        # derive from find_* columns
        keys = [k for k in (it[0] or {}).keys() if isinstance(k,str) and k.startswith("find_")]
        m = {}
        for r in it:
            for k in keys:
                m[k] = m.get(k,0) + (r.get(k) or 0)
        cat = [{"category": k.replace("find_",""), "count": v} for k,v in m.items()]
    categories_top = [[c.get("category"), c.get("count")] for c in (cat or [])]
    targets = D.get("targets") or {"default":{"accept":90,"dai":90,"rpr":99}}
    phases = D.get("phases")
    # costs
    cost_corr = corr(tokens, acc)

    # retests passthrough
    retests = D.get("retests")

    # summary
    summary = {}
    if it:
        summary = {
            "iterations": max(iters),
            "attempts": sum((r.get("resolutions_attempted") or 0) for r in it),
            "accepted": sum((r.get("resolutions_accepted") or 0) for r in it),
            "acceptance_pct": None if not summary else None
        }
        att = summary["attempts"]; acc_sum = summary["accepted"]
        summary["acceptance_pct"] = (acc_sum/att*100.0) if att else None
        # DAI/RPR endpoints
        first = it[0]; last = it[-1]
        summary["DAI_start"] = first.get("DAI_score"); summary["DAI_end"] = last.get("DAI_score")
        summary["RPR_start"] = first.get("RPR_percent"); summary["RPR_end"] = last.get("RPR_percent")

    return {
        "generated_at": embed_data.get("generated_at"),
        "summary": summary,
        "shewhart": sh,
        "run_rules": rr,
        "ewma_last": ew,
        "categories_top": categories_top[:10],
        "targets": targets,
        "phases": phases,
        "costs": {"corr_tokens_accept": cost_corr},
        "retests": retests
    }

def generate(output_dir: str, title="Cerberus v1.3 — Run Report"):
    os.makedirs(output_dir, exist_ok=True)
    scrub_patterns = load_scrub_list(output_dir)

    paths = {
        "iterations": os.path.join(output_dir, "iterations.csv"),
        "iterations_prev": os.path.join(output_dir, "iterations_prev.csv"),
        "compliance": os.path.join(output_dir, "compliance.csv"),
        "findings": os.path.join(output_dir, "findings.csv"),
        "phases": os.path.join(output_dir, "phases.csv"),
        "category_counts": os.path.join(output_dir, "category_counts.csv"),
        "metrics": os.path.join(output_dir, "metrics.json"),
        "signals": os.path.join(output_dir, "signals.json"),
        "targets": os.path.join(output_dir, "targets.json"),
        "retests": os.path.join(output_dir, "retests.csv"),
        "models": os.path.join(output_dir, "models.json")
    }

    dfs = {k: read_csv(p) if p.endswith(".csv") else None for k,p in paths.items()}
    json_blobs = {}
    for k, p in paths.items():
        if p.endswith(".csv"):
            df = dfs[k]
            json_blobs[k] = to_records(df, scrub_patterns) if df is not None else None
        else:
            if os.path.exists(p):
                try:
                    raw = json.load(open(p,"r",encoding="utf-8"))
                    def scrub(obj):
                        if isinstance(obj, str): return _scrub_str(obj, scrub_patterns)
                        if isinstance(obj, list): return [scrub(x) for x in obj]
                        if isinstance(obj, dict): return {kk: scrub(vv) for kk,vv in obj.items()}
                        return obj
                    json_blobs[k] = scrub(raw)
                except Exception:
                    json_blobs[k] = None
            else:
                json_blobs[k] = None

    downloads = {}
    for k in ("iterations","compliance","findings","retests","phases","category_counts"):
        p = paths[k]
        if os.path.exists(p):
            url, name = encode_data_url(p, "text/csv")
            downloads[k] = {"url": url, "name": name}
        else:
            downloads[k] = None
    for k in ("metrics","signals","targets","models"):
        p = paths[k]
        if os.path.exists(p):
            url, name = encode_data_url(p, "application/json")
            downloads[k] = {"url": url, "name": name}
        else:
            downloads[k] = None

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%MZ")
    embed_json = {
        "title": title,
        "generated_at": now,
        "data": json_blobs,
        "downloads": downloads,
        "banned_patterns_info": [p for p in scrub_patterns],
        "defaults": {
            "targets": {"default": {"accept": 90, "dai": 90, "rpr": 99}},
            "phases": ["antithesis","transition","seeder"]
        }
    }

    # Build HTML
    tpl = ("""<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>__TITLE__</title>
<style>
:root { --bg:#0b0b0b; --fg:#f6f7f8; --mut:#b8c0cc; --card:#14161a; --line:#21262d; --good:#10b981; --warn:#f59e0b; --bad:#ef4444; --info:#60a5fa; --accent:#2563eb; }
html, body { margin:0; background:var(--bg); color:var(--fg); font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; }
header { position:sticky; top:0; z-index:10; background:linear-gradient(180deg,#0e1116,#0b0e12); border-bottom:1px solid var(--line); padding:1.1rem 1.25rem; }
h1 { margin:.1rem 0 .25rem; font-size:1.35rem; }
main { max-width:1200px; margin:0 auto; padding:1.25rem 1rem 2.5rem; }
.card { background:var(--card); border:1px solid var(--line); border-radius:14px; padding:1rem 1.25rem; margin:1rem 0; position:relative; }
.row { display:flex; gap:1rem; align-items:center; flex-wrap:wrap; }
.pill { display:inline-block; padding:.2rem .5rem; border-radius:999px; border:1px solid var(--line); background:#0e1218; font-size:.85rem; }
.mut { color:var(--mut); }
.btn { display:inline-block; padding:.45rem .75rem; border-radius:8px; border:1px solid var(--line); background:#0e1218; cursor:pointer; }
.grid { display:grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap:1rem; }
@media (max-width: 900px) { .grid { grid-template-columns: 1fr; } }
table { border-collapse: collapse; width: 100%; font-size:.95rem; }
th, td { text-align:left; padding:.55rem; border-bottom:1px dashed var(--line); vertical-align:top; }
.tabs { margin-top:.5rem; }
.tab-links a { display:inline-block; padding:.4rem .7rem; margin:.2rem .2rem 0 0; border:1px solid var(--line); border-radius:8px; background:#0e1218; text-decoration:none; color:inherit; cursor:pointer; }
.tab-links a.active { outline:2px solid #334155; }
.tab { display:none; } .tab.active { display:block; }
.small { font-size:.9rem; }
.kv { display:flex; gap:1rem; flex-wrap:wrap; }
.kv b { min-width:140px; display:inline-block; }
.badge { display:inline-block; padding:.2rem .5rem; margin:.15rem; border:1px solid var(--line); border-radius:999px; position:relative; }
.badge.ok { background:#0b1a14; border-color:#0f2f22; }
.badge.ng { background:#1a0b0b; border-color:#3b1111; }
.banner { padding:.8rem 1rem; border-radius:10px; border:1px solid var(--line); margin-bottom:.75rem; }
.banner.stop { background:#1a0b0b; border-color:#3b1111; }
.banner.good { background:#0b1a14; border-color:#0f2f22; }
.mask { opacity:.6 }
.helpbar { position:absolute; top:.6rem; right:.6rem; display:flex; gap:.35rem; z-index:5; pointer-events:none; }
.help-btn { font-size:.85rem; padding:.28rem .6rem; border-radius:8px; border:1px solid #1d4ed8; background:var(--accent); color:#fff; cursor:pointer; box-shadow:0 2px 8px rgba(37,99,235,.25); pointer-events:auto; }
.help-btn:hover { filter:brightness(1.05); transform: translateY(-1px); }
.modal { position:fixed; inset:0; background:rgba(0,0,0,.55); display:none; align-items:center; justify-content:center; z-index:50; }
.modal .panel { background:var(--card); border:1px solid var(--line); border-radius:12px; padding:1rem 1.2rem; max-width:820px; width:min(92vw,820px); max-height:80vh; overflow:auto; }
.modal .title { font-weight:600; margin-bottom:.35rem; display:flex; justify-content:space-between; align-items:center;}
.modal .close { cursor:pointer; }
.key dl { display:grid; grid-template-columns: 180px 1fr; gap:.35rem .75rem; }
.key dt { font-weight:600; } .key dd { margin:0; }
.tip { cursor:help; display:inline-block; margin-left:.35rem; width:1.05em; height:1.05em; line-height:1.05em; text-align:center; border:1px solid var(--line); border-radius:50%; font-size:.75rem; color: var(--mut); position:relative; }
.tip:hover::after { content: attr(data-tip); position:absolute; background: var(--card); border: 1px solid var(--line); padding:.4rem .55rem; border-radius:8px; top: 1.4rem; right:0; width: 280px; color: var(--fg); box-shadow: 0 4px 20px rgba(0,0,0,.35); white-space: normal; z-index: 60; }
.badge[data-tip]:hover::after { content: attr(data-tip); position:absolute; background: var(--card); border: 1px solid var(--line); padding:.4rem .55rem; border-radius:8px; top: 1.6rem; left:0; min-width: 260px; color: var(--fg); box-shadow: 0 4px 20px rgba(0,0,0,.35); white-space: normal; z-index: 60; }
.input { background:#0e1218; color:var(--fg); border:1px solid var(--line); border-radius:8px; padding:.4rem .55rem; }
.inline-controls { display:flex; gap:.5rem; align-items:center; margin-bottom:.4rem; flex-wrap:wrap; }
pre.json { background:#0e1218; border:1px solid var(--line); border-radius:10px; padding:.6rem .8rem; overflow:auto; max-height:300px; }
</style>
<script>
const CERB = __EMBED_JSON__;
const fmt = n => (n===null || n===undefined || Number.isNaN(n)) ? "—" : (typeof n === "number" ? (Math.round(n*100)/100).toString() : n);
const pct = n => (n===null || n===undefined || Number.isNaN(n)) ? "—" : (Math.round(n*10)/10).toString() + "%";
const sum = a => a.reduce((x,y)=>x+(y||0),0);
const last = arr => arr.length? arr[arr.length-1][1] : null;
function mean(a){ const xs=a.filter(v=>v!=null); return xs.length? xs.reduce((x,y)=>x+y,0)/xs.length : null; }
function spark(series, stroke="#9ad1ff", width=360, height=48, margin=4, markerX=null) {
  const vs = series.map(p=>p[1]).filter(v => v!==null && v!==undefined);
  if (!vs.length) return "<div class='mut small'>No data</div>";
  let vmin = Math.min(...vs), vmax = Math.max(...vs); if (vmax === vmin) vmax = vmin + 1e-9;
  const xs = series.map(p=>p[0]); let xmin = Math.min(...xs), xmax = Math.max(...xs); if (xmax===xmin) xmax=xmin+1;
  const rngx = xmax-xmin;
  const pts = series.filter(p=>p[1]!=null).map(([x,v]) => {
    const X = margin + (x - xmin) / rngx * (width - 2*margin);
    const Y = height - margin - (v - vmin) / (vmax - vmin) * (height - 2*margin);
    return `${X.toFixed(1)},${Y.toFixed(1)}`;
  }).join(" ");
  return `<svg width='${width}' height='${height}'><polyline fill='none' stroke='${stroke}' stroke-width='2' points='${pts}'/></svg>`;
}
function shewhart(series) {
  const vs = series.map(p=>p[1]).filter(v=>v!=null);
  if (!vs.length) return {mean:null, sigma:null, ucl:null, lcl:null, breaches:0};
  const mean = vs.reduce((a,b)=>a+b,0)/vs.length;
  const variance = vs.reduce((a,b)=>a+(b-mean)**2,0)/vs.length;
  const sigma = Math.sqrt(variance);
  const ucl = mean + 3*sigma, lcl = mean - 3*sigma;
  const breaches = vs.filter(v => v>ucl || v<lcl).length;
  return {mean, sigma, ucl, lcl, breaches};
}
function runRules(series){ // 2-of-3 ±2σ; 8-in-a-row
  const vs = series.map(p=>p[1]).filter(v=>v!=null);
  if (!vs.length) return {breaches:0, reasons:[]};
  const m = vs.reduce((a,b)=>a+b,0)/vs.length;
  const variance = vs.reduce((a,b)=>a+(b-m)**2,0)/vs.length;
  const s = Math.sqrt(variance) || 1e-9;
  const hi2 = m + 2*s, lo2 = m - 2*s;
  let twoOfThree = 0, eightOnSide = 0, reasons = [];
  for (let i=0;i<=vs.length-3;i++){
    const w = vs.slice(i,i+3);
    const hi = w.filter(v=>v>hi2).length;
    const lo = w.filter(v=>v<lo2).length;
    if (hi>=2 || lo>=2){ twoOfThree++; reasons.push(`Rule: 2-of-3 beyond ±2σ @ window ${i+1}-${i+3}`); }
  }
  let cnt=0, side=null;
  for (let i=0;i<vs.length;i++){
    const cur = vs[i]>=m ? 'H' : 'L';
    if (side===null || cur===side){ cnt++; } else { cnt=1; side=cur; }
    side = (side===null)?cur:side;
    if (cnt>=8){ eightOnSide++; reasons.push(`Rule: 8-in-a-row on ${side==='H'?'high':'low'} side starting @ index ${i-cnt+2}`); cnt=0; side=null; }
  }
  return {breaches: twoOfThree + eightOnSide, reasons};
}
function ewma(series, alpha=0.2) {
  let y=null, out=[];
  for (const [x,v] of series) { if (v==null) { out.push([x,null]); continue; } y = (y==null) ? v : alpha*v + (1-alpha)*y; out.push([x,y]); }
  return out;
}
function showTab(id, el) {
  document.querySelectorAll('.tab').forEach(n => n.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.tab-links a').forEach(a => a.classList.remove('active'));
  el.classList.add('active');
}
function section(id){ return document.getElementById(id); }

function mapField(row, keys){
  for (const k of keys){
    if (row.hasOwnProperty(k) && row[k]!=null && row[k]!=="" ) return row[k];
    // try case-insensitive
    const found = Object.keys(row).find(kk => kk.toLowerCase()===k.toLowerCase());
    if (found && row[found]!=null && row[found]!=="") return row[found];
  }
  return null;
}
function toNumber(x){ const n = Number(x); return (isNaN(n)? null : n); }
function normIterations(rows){
  if (!rows || !rows.length) return [];
  return rows.map(r => {
    const iter = toNumber(mapField(r, ["iter","iteration","step","t","index"])) || null;
    const att  = toNumber(mapField(r, ["resolutions_attempted","attempts","tries","total_attempts"])) || null;
    const accp = toNumber(mapField(r, ["Acceptance","acceptance","accept_pct","acceptance_pct"])) ;
    const accd = toNumber(mapField(r, ["resolutions_accepted","accepted","accepts","accepted_count"]));
    const dai  = toNumber(mapField(r, ["DAI_score","dai","dai_score","diagnostic_index"]));
    const rpr  = toNumber(mapField(r, ["RPR_percent","rpr","rpr_pct","pass_rate"]));
    const tin  = toNumber(mapField(r, ["tokens_in_iter","tokens_in","tok_in"]));
    const tout = toNumber(mapField(r, ["tokens_out_iter","tokens_out","tok_out"]));
    const wall = toNumber(mapField(r, ["wall_ms_iter","wall_ms","elapsed_ms","duration_ms"]));
    const acceptance = (accp!=null) ? accp : ((att && accd!=null)? (accd/att*100) : null);
    return { iter, attempts: att, accepted: accd, acceptance, dai, rpr, tokens: (tin!=null||tout!=null)? ((tin||0)+(tout||0)) : null, wall };
  });
}
function detectResolution(itSeries, daiSeries, phases, targets){
  // Compute resolution based on EWMA crossing phase-specific antithesis targets with sustain
  let aStart = 1, aEnd = null;
  if (phases && phases.length){
    aStart = phases[0]?.iter || 1;
    if (phases.length>1){ aEnd = (phases[1].iter||null); }
  }
  const alpha=0.2;
  function ewmaOnly(series){ let y=null,out=[]; for (const [x,v] of series){ if(v==null){ out.push([x,null]); continue;} y=(y==null? v : alpha*v+(1-alpha)*y); out.push([x,y]); } return out; }
  const ewA = ewmaOnly(itSeries);
  const ewD = ewmaOnly(daiSeries);
  const T = targets || {default:{accept:85,dai:85}};
  const tA = (T.phases && T.phases.antithesis && T.phases.antithesis.accept) || (T.default && T.default.accept) || 85;
  const tD = (T.phases && T.phases.antithesis && T.phases.antithesis.dai) || (T.default && T.default.dai) || 85;
  const minIter = (aStart||1) + 20;
  const sustain = 8;
  function firstSustainedAt(ew, thr){
    const arr = ew.filter(p=>p[1]!=null);
    for (let i=0;i<arr.length;i++){
      const it = arr[i][0]; if (it<minIter) continue;
      let ok=true;
      for (let k=0;k<sustain;k++){ const j=i+k; if (j>=arr.length){ ok=false; break; } if (!(arr[j][1]>=thr)) { ok=false; break; } }
      if (ok) return it;
    }
    return null;
  }
  const resA = firstSustainedAt(ewA, tA);
  const resD = firstSustainedAt(ewD, tD);
  const resolved = (resA!=null && resD!=null)? Math.max(resA, resD) : (resA||resD);
  return { resolved, resA, resD, sustain };
}
function downloadModelsJson(){
  try{
    const obj = window.MODELS || {};
    const blob = new Blob([JSON.stringify(obj, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download='models.json'; a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 2000);
  }catch(e){ console.error(e); }
}
function openModelDesigner(){
  const names = Object.keys(window.MODELS||{});
  const active = (document.getElementById('model-select')?.value)||names[0]||'Baseline';
  const m = (window.MODELS && window.MODELS[active]) || {weights:{accept_mean:0.4,dai_end:0.2,rpr_end:0.2,spc_penalty:-0.2,nonreg_bad_last:-0.2}};
  const w = Object.assign({accept_mean:0.4,dai_end:0.2,rpr_end:0.2,spc_penalty:-0.2,nonreg_bad_last:-0.2}, m.weights||{});
  const inputs = Object.keys(w).map(k=>`<tr><td>${k}</td><td><input id="md-${k}" class="input" type="number" step="0.01" value="${w[k]}"/></td></tr>`).join("");
  const addBox = `<div style="margin-top:.6rem"><b>Add/rename profile</b> <input id="md-name" class="input" placeholder="Profile name" value="${active}"/></div>`;
  const html = `<div>Profile: <b>${active}</b></div><div style="overflow:auto;max-height:50vh"><table><thead><tr><th>Feature</th><th>Weight</th></tr></thead><tbody>${inputs}</tbody></table></div>${addBox}
    <div style="margin-top:.6rem;display:flex;gap:.4rem;justify-content:flex-end">
      <button class="btn" id="md-save">Save</button>
      <button class="btn" id="md-download">Export models.json</button>
    </div>`;
  openModal('Model Designer', html);
  setTimeout(()=>{
    const btn = document.getElementById('md-save');
    const dl  = document.getElementById('md-download');
    if (btn){
      btn.onclick = ()=>{
        const name = document.getElementById('md-name').value.trim() || active;
        const weights = {};
        Object.keys(w).forEach(k=>{ const v = parseFloat(document.getElementById('md-'+k).value); weights[k] = isNaN(v)? 0 : v; });
        window.MODELS = window.MODELS || {};
        window.MODELS[name] = {weights};
        localStorage.setItem('cerb_models', JSON.stringify(window.MODELS));
        // refresh selector
        const sel = document.getElementById('model-select');
        if (sel){
          const cur = sel.value;
          sel.innerHTML = Object.keys(window.MODELS).map(n=>`<option value="${n}">Profile: ${n}</option>`).join("");
          sel.value = name;
          localStorage.setItem('cerb_model', name);
          if (typeof evalModel==='function') evalModel();
        }
        closeModal();
      };
    }
    if (dl){ dl.onclick = ()=>downloadModelsJson(); }
  }, 50);
}

function hide(id){ const el = section(id); if (el) el.classList.add('mask'); }
function copyText(text){ try{ navigator.clipboard.writeText(text); }catch(e){} }

// Raw table renderer (4a)
function renderTable(containerId, rows){
  const el = section(containerId); if (!el) return;
  if (!rows || !rows.length){ el.innerHTML = "<div class='mut small'>No data</div>"; return; }
  const cols = Array.from(rows.reduce((s,r)=>{ Object.keys(r).forEach(k=>s.add(k)); return s; }, new Set()));
  const filterId = containerId+"-flt";
  const total = rows.length;
  el.innerHTML = `<div class="inline-controls"><input id="${filterId}" class="input" placeholder="Filter rows (substring match)"/><span class="mut small" id="${containerId}-count">${total} rows</span></div>
  <div style="overflow:auto; max-height:360px"><table><thead><tr>${cols.map(c=>`<th>${c}</th>`).join("")}</tr></thead><tbody id="${containerId}-body"></tbody></table></div>`;
  function draw(filter){
    const body = section(containerId+"-body");
    const f = (filter||"").toLowerCase();
    let shown=0;
    const html = rows.filter(r=>{
      if(!f) return true;
      for (const k of cols){ const v=r[k]; if (v!=null && String(v).toLowerCase().includes(f)) return true; }
      return false;
    }).slice(0,2000).map(r=>{
      shown++;
      return "<tr>"+cols.map(c=>`<td>${r[c]===undefined?"":r[c]}</td>`).join("")+"</tr>";
    }).join("");
    body.innerHTML = html || "<tr><td class='mut small' colspan='"+cols.length+"'>No matches.</td></tr>";
    section(containerId+"-count").textContent = (shown===total? `${total} rows` : `${shown}/${total} rows`);
  }
  section(filterId).addEventListener("input", e=>draw(e.target.value));
  draw("");
}

// JSON prettier (4a)
function renderJSON(containerId, obj){
  const el = section(containerId); if(!el) return;
  if (!obj){ el.innerHTML = "<div class='mut small'>No data</div>"; return; }
  const pretty = JSON.stringify(obj, null, 2);
  el.innerHTML = `<div class="inline-controls"><button class="btn" onclick="copyText(document.getElementById('${containerId}-pre').innerText)">Copy</button></div><pre id="${containerId}-pre" class="json"></pre>`;
  section(containerId+"-pre").textContent = pretty;
}

function openModal(title, html){
  const m = document.getElementById('modal'); 
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = html;
  m.style.display = 'flex';
}
function closeModal(){ document.getElementById('modal').style.display = 'none'; }

document.addEventListener("DOMContentLoaded", () => {
  /*MODEL_WIRING*/
  let MODELS = CERB.data.models || { "Baseline": { weights: { accept_mean: 0.4, dai_end: 0.2, rpr_end: 0.2, spc_penalty: -0.2, nonreg_bad_last: -0.2 } } };
  try { const stored = localStorage.getItem('cerb_models'); if (stored) { const m = JSON.parse(stored); if (m && typeof m === 'object') { MODELS = m; } } } catch(e) {} 
  window.MODELS = MODELS;
  const modelNames = Object.keys(MODELS);
  const select = document.getElementById('model-select');
  if (select){
    // populate options
    select.innerHTML = "<option value=''>Profile: Baseline</option>"+modelNames.map(n=>`<option value="${n}">Profile: ${n}</option>`).join("");
    // restore selection
    const saved = localStorage.getItem('cerb_model') || "";
    if (saved && modelNames.includes(saved)) { select.value = saved; }
    select.addEventListener('change', e=>{ localStorage.setItem('cerb_model', e.target.value); evalModel(); });
  }

  function evalModel(){
    const name = (select && select.value) || "Baseline";
    const def = MODELS[name] || MODELS["Baseline"];
    // collect features
    const accVals = it.map(p=>p[1]).filter(v=>v!=null);
    const accept_mean = accVals.length? accVals.reduce((a,b)=>a+b,0)/accVals.length : null;
    const dai_end = last(dai);
    const rpr_end = last(rpr);
    const spc_penalty = ( (shewhart(it).breaches||0) + (shewhart(dai).breaches||0) + (shewhart(rpr).breaches||0) );
    // non-regression last %
    let nonreg_last = null;
    const rtEl = document.getElementById('retests-spark');
    if (rtEl && rtEl.innerText){
      // can't scrape %; recompute from CERB.data.retests if present
      if (CERB.data.retests && CERB.data.retests.length){
        const by={};
        CERB.data.retests.forEach(r=>{ const I = Number(r.current_iter||r.previous_iter||0); if(!I) return; by[I]=by[I]||{tot:0,bad:0}; by[I].tot++; const st=(r.status||'').toUpperCase(); if (st==='REOPENED'||st==='REGRESSED') by[I].bad++; });
        const ks = Object.keys(by).map(x=>Number(x)).sort((a,b)=>a-b);
        if (ks.length){ const I=ks[ks.length-1]; nonreg_last = by[I].tot? (by[I].bad/by[I].tot*100) : null; }
      }
    }

    // scoring
    const w = (def.weights||{});
    function contrib(label, value, scale='raw'){
      if (value==null) return {label, value:'—', score:0};
      let v=value;
      if (scale==='pct0_100' && v<=1) v = v*100; // normalize if given as 0-1
      return {label, value: (typeof v==='number' ? (Math.round(v*100)/100) : v), score: (w[label]||0) * (typeof v==='number' ? v : 0)};
    }
    const parts = [
      contrib('accept_mean', accept_mean, 'pct0_100'),
      contrib('dai_end', dai_end),
      contrib('rpr_end', rpr_end),
      contrib('spc_penalty', -spc_penalty), // negative
      contrib('nonreg_bad_last', nonreg_last)
    ];
    const total = parts.reduce((s,p)=>s + (p.score||0), 0);
    document.getElementById('model-name').textContent = name;
    document.getElementById('model-score').textContent = isNaN(total)? '—' : Math.round(total*10)/10;
    document.getElementById('model-breakdown').innerHTML = "<table><thead><tr><th>Feature</th><th>Value</th><th>Weight</th><th>Contribution</th></tr></thead><tbody>"+
      parts.map(p=>`<tr><td>${p.label}</td><td>${p.value}</td><td>${w[p.label]||0}</td><td>${Math.round((p.score||0)*100)/100}</td></tr>`).join("")+
      "</tbody></table>";
  }

  // Derived features
  function renderDerived(){
    const slopeA = linregSlope(it, 20); const slopeD = linregSlope(dai, 20); const slopeR = linregSlope(rpr, 20);
    const lastSlopeA = last(slopeA), lastSlopeD = last(slopeD), lastSlopeR = last(slopeR);
    const meanA100 = avgIn(it, Math.max(1, (iters-99)||1), iters);
    const meanD100 = avgIn(dai, Math.max(1, (iters-99)||1), iters);
    const meanR100 = avgIn(rpr, Math.max(1, (iters-99)||1), iters);
    const html = `<div class='kv'>
      <div><b>Slope A (last 20)</b> ${fmt(lastSlopeA)}</div>
      <div><b>Slope DAI (last 20)</b> ${fmt(lastSlopeD)}</div>
      <div><b>Slope RPR (last 20)</b> ${fmt(lastSlopeR)}</div>
      <div><b>Mean A (last 100)</b> ${fmt(meanA100)}</div>
      <div><b>Mean DAI (last 100)</b> ${fmt(meanD100)}</div>
      <div><b>Mean RPR (last 100)</b> ${fmt(meanR100)}</div>
    </div>`;
    document.getElementById('derived-content').innerHTML = html;
  }

  // Antithesis Resolution detection
  function renderResolution(){
    // find antithesis bounds
    let aStart=1, aEnd = (iters||0);
    if (CERB.data.phases && CERB.data.phases.length){
      // assume first row is antithesis start
      aStart = CERB.data.phases[0]?.iter || 1;
      // end at next phase start - 1
      if (CERB.data.phases.length>1){
        aEnd = (CERB.data.phases[1].iter || aEnd) - 1;
      }
    } else {
      aEnd = Math.min(300, iters||300);
    }
    const alpha=0.2;
    const ewA = ewmaOnly(it, alpha); const ewD = ewmaOnly(dai, alpha);
    const T = (CERB.data.targets && CERB.data.targets) || {default:{accept:85,dai:85}};
    const tA = (T.phases && T.phases.antithesis && T.phases.antithesis.accept) || T.default.accept || 85;
    const tD = (T.phases && T.phases.antithesis && T.phases.antithesis.dai) || T.default.dai || 85;

    const minIter = aStart + 20;
    const sustain = 8;
    const resA = firstSustainedAt(ewA, minIter, tA, sustain);
    const resD = firstSustainedAt(ewD, minIter, tD, sustain);
    const resolved = (resA!=null && resD!=null)? Math.max(resA, resD) : (resA||resD);
    const sustainLen = sustain;

    // Seeder-weighted focus (final 100 iters)
    const sStart = Math.max( (iters||0) - 99, 1 );
    const sA = avgIn(it, sStart, iters);
    const sD = avgIn(dai, sStart, iters);
    const sR = avgIn(rpr, sStart, iters);

    const html = `<div class='kv'>
      <div><b>Antithesis window</b> ${aStart}–${aEnd}</div>
      <div><b>Resolution iteration</b> ${resolved==null?'—':resolved} <span class='mut small'>(sustain ${sustainLen})</span></div>
      <div><b>Meets A target in EWMA</b> ${resA==null?'No':'Yes @ '+resA}</div>
      <div><b>Meets DAI target in EWMA</b> ${resD==null?'No':'Yes @ '+resD}</div>
    </div>
    <div class='kv' style='margin-top:.35rem'>
      <div><b>Seeder-weighted mean A (last 100)</b> ${fmt(sA)}</div>
      <div><b>Seeder-weighted mean DAI (last 100)</b> ${fmt(sD)}</div>
      <div><b>Seeder-weighted mean RPR (last 100)</b> ${fmt(sR)}</div>
    </div>`;
    document.getElementById('resolve-content').innerHTML = html;
  }

  evalModel();
  renderDerived();
  renderResolution();

  // Make Explain robust: attach listeners that always open a modal
  document.querySelectorAll('.help-btn').forEach(btn => {
    btn.addEventListener('click', (ev) => {
      ev.preventDefault(); ev.stopPropagation();
      try { if (typeof help === 'function') { help('all'); return; } } catch(e) {}
      try { openModal('Summary', 'No summary available.'); } catch(e) { console.error(e); }
    }, true);
  });

  const D = CERB.data;
  // Series (schema-mapped)
  const NORM = normIterations(CERB.data.iterations || []);
  const it = NORM.map(r => [Number(r.iter), r.acceptance]);
  const dai = NORM.map(r => [Number(r.iter), r.dai]);
  const rpr = NORM.map(r => [Number(r.iter), r.rpr]);
  const toks = NORM.map(r => [Number(r.iter), r.tokens]);
  const wall = NORM.map(r => [Number(r.iter), r.wall]);

  // Summary numbers
  const iters = D.iterations && D.iterations.length ? Math.max(...D.iterations.map(r=>Number(r.iter)||0)) : "—";
  const fnd = D.iterations ? sum(D.iterations.map(r => r.findings_total||0)) : "—";
  const att = D.iterations ? sum(D.iterations.map(r => r.resolutions_attempted||0)) : "—";
  const acc = D.iterations ? sum(D.iterations.map(r => r.resolutions_accepted||0)) : "—";
  const ar  = (att && acc!=null && att>0) ? Math.round((acc/att*100)*10)/10 : "—";
  const ds = D.iterations && D.iterations.length ? D.iterations.find(r=>Number(r.iter)===1)?.DAI_score : "—";
  const de = D.iterations && D.iterations.length ? D.iterations.find(r=>Number(r.iter)===iters)?.DAI_score : "—";
  const rs = D.iterations && D.iterations.length ? D.iterations.find(r=>Number(r.iter)===1)?.RPR_percent : "—";
  const re = D.iterations && D.iterations.length ? D.iterations.find(r=>Number(r.iter)===iters)?.RPR_percent : "—";

  section("sum-iters").textContent = fmt(iters);
  section("sum-findings").textContent = fmt(fnd);
  section("sum-attempts").textContent = fmt(att);
  section("sum-accepted").textContent = fmt(acc);
  section("sum-accept").textContent = fmt(ar);
  section("sum-dai").textContent = fmt(ds)+" → "+fmt(de);
  section("sum-rpr").textContent = fmt(rs)+" → "+fmt(re);

  // Resolution detection for marker lines
  const RESMARK = detectResolution(it, dai, CERB.data.phases, CERB.data.targets);
  // Insights charts
  section("spark-accept").innerHTML = spark(it, "#9ad1ff", 360, 48, 4, RESMARK.resolved);
  section("spark-dai").innerHTML    = spark(dai, "#34d399", 360, 48, 4, RESMARK.resolved);
  section("spark-rpr").innerHTML    = spark(rpr, "#fbbf24");

  // Category heat (fallback derive)
  const heat = [];
  if (D.category_counts && D.category_counts.length) {
    for (const r of D.category_counts) { heat.push([r.category, Number(r.count||0)]); }
  } else if (D.iterations && D.iterations.length) {
    const keys = Object.keys(D.iterations[0]||{}).filter(k=>k.startsWith("find_"));
    const map = {}; for (const r of D.iterations) for (const k of keys) map[k]=(map[k]||0)+Number(r[k]||0);
    for (const k of Object.keys(map)) heat.push([k.replace(/^find_/,""), map[k]]);
  }
  heat.sort((a,b)=>b[1]-a[1]);
  if (!heat.length) section("heatbar").innerHTML = "<div class='mut small'>No data</div>";
  else {
    const total = heat.reduce((a,b)=>a+b[1],0)||1; const palette=["#60a5fa","#34d399","#fbbf24","#f87171","#a78bfa","#f472b6","#22d3ee"];
    const bar = heat.map((h,i)=>`<div title='${h[0]}: ${h[1]}' style='width:${Math.max(2,Math.round(h[1]/total*100))}%;background:${palette[i%palette.length]};height:16px;border-radius:4px'></div>`).join("");
    section("heatbar").innerHTML = `<div style='display:flex;gap:4px'>${bar}</div><div class='mut small' style='margin-top:.35rem'>${heat.slice(0,6).map(h=>`${h[0]}: ${h[1]}`).join(", ")}${heat.length>6?" ...":""}</div>`;
  }

  // Phases & targets
  let phases = [];
  if (D.phases && D.phases.length) {
    let lastPhase=null, start=null; for (const r of D.phases.sort((a,b)=>a.iter-b.iter)) {
      if (lastPhase===null){ lastPhase=r.phase; start=r.iter; }
      else if (r.phase!==lastPhase){ phases.push({name:lastPhase,start:start,end:r.iter-1}); lastPhase=r.phase; start=r.iter; }
    }
    if (lastPhase!==null) phases.push({name:lastPhase,start:start,end:iters});
  } else if (iters!=="—") {
    phases=[{name:"antithesis",start:1,end:Math.min(300,iters)},
            {name:"transition",start:301,end:Math.min(380,iters)},
            {name:"seeder",start:381,end:iters}];
  }
  const T = (CERB.data.targets && CERB.data.targets) || CERB.defaults.targets;
  const P = (CERB.data.targets && CERB.data.targets.phases) || {};

  function phaseMean(series, s, e) {
    const xs = series.filter(([x,_])=>x>=s && x<=e).map(p=>p[1]).filter(v=>v!=null);
    if (!xs.length) return null;
    return xs.reduce((a,b)=>a+b,0)/xs.length;
  }
  let chips = [];
  for (const ph of phases) {
    const ma = phaseMean(it, ph.start, ph.end);
    const md = phaseMean(dai, ph.start, ph.end);
    const mr = phaseMean(rpr, ph.start, ph.end);
    const tA = (P[ph.name] && P[ph.name].accept) || (T.default && T.default.accept) || 0;
    const tD = (P[ph.name] && P[ph.name].dai)    || (T.default && T.default.dai)    || 0;
    const tR = (P[ph.name] && P[ph.name].rpr)    || (T.default && T.default.rpr)    || 0;
    const dA = (ma!=null)? (Math.round((ma - tA)*10)/10) : null;
    const dD = (md!=null)? (Math.round((md - tD)*10)/10) : null;
    const dR = (mr!=null)? (Math.round((mr - tR)*10)/10) : null;
    const okA = (ma!=null && ma >= tA);
    const okD = (md!=null && md >= tD);
    const okR = (mr!=null && mr >= tR);
    chips.push(`<div style='margin:.2rem 0'>
      <div class='pill'>${ph.name} <span class="mut small">(${ph.start}–${ph.end})</span></div>
      <span class='badge ${okA?'ok':'ng'}' data-tip='Acceptance mean ${fmt(ma)} vs target ${tA} (Δ ${dA>=0?'+':''}${fmt(dA)})'>A ≥ ${tA} (${fmt(ma)})</span>
      <span class='badge ${okD?'ok':'ng'}' data-tip='DAI mean ${fmt(md)} vs target ${tD} (Δ ${dD>=0?'+':''}${fmt(dD)})'>DAI ≥ ${tD} (${fmt(md)})</span>
      <span class='badge ${okR?'ok':'ng'}' data-tip='RPR mean ${fmt(mr)} vs target ${tR} (Δ ${dR>=0?'+':''}${fmt(dR)})'>RPR ≥ ${tR} (${fmt(mr)})</span>
    </div>`);
  }
  section("phase-targets").innerHTML = chips.join("");

  // SPC & Run-rules
  const shA = shewhart(it), shD = shewhart(dai), shR = shewhart(rpr);
  const rrA = runRules(it), rrD = runRules(dai), rrR = runRules(rpr);
  const ewA = ewma(it), ewD = ewma(dai), ewR = ewma(rpr);
  section("shewhart").innerHTML = `<div class='kv'>
    <div><b>A</b> μ=${fmt(shA.mean)} σ=${fmt(shA.sigma)} • breaches=${shA.breaches}</div>
    <div><b>DAI</b> μ=${fmt(shD.mean)} σ=${fmt(shD.sigma)} • breaches=${shD.breaches}</div>
    <div><b>RPR</b> μ=${fmt(shR.mean)} σ=${fmt(shR.sigma)} • breaches=${shR.breaches}</div>
  </div>`;
  section("ewma").innerHTML = `<div class='kv'>
    <div><b>A</b> EWMA=${fmt(last(ewA))}</div>
    <div><b>DAI</b> EWMA=${fmt(last(ewD))}</div>
    <div><b>RPR</b> EWMA=${fmt(last(ewR))}</div>
  </div>`;
  const runruleReasons = [...rrA.reasons, ...rrD.reasons, ...rrR.reasons];
  section("runrules").innerHTML = runruleReasons.length ? ("<ul class='small'>" + runruleReasons.slice(0,8).map(x=>`<li>${x}</li>`).join("") + "</ul>") : "<div class='mut small'>No run-rule signals.</div>";

  const targetDefault = (T.default || {accept:90,dai:90,rpr:99});
  const globalFails = [(ar<targetDefault.accept), (Number(de)<targetDefault.dai), (Number(re)<targetDefault.rpr)].filter(Boolean).length;
  const spcBreaches = (shA.breaches||0) + (shD.breaches||0) + (shR.breaches||0);
  const rrBreaches = (rrA.breaches||0) + (rrD.breaches||0) + (rrR.breaches||0);
  if (spcBreaches>0 || rrBreaches>0 || globalFails>=2) {
    const msgs = [];
    if (spcBreaches>0) msgs.push(spcBreaches+' Shewhart breach(es)');
    if (rrBreaches>0) msgs.push(rrBreaches+' run-rule signal(s)');
    if (globalFails>=2) msgs.push(globalFails+' global target failure(s)');
    section("gate-banner").innerHTML = `<div class='banner stop'><b>Stop the line:</b> ${msgs.join(' • ')}</div>`;
  } else {
    section("gate-banner").innerHTML = `<div class='banner good'><b>In control:</b> No SPC/run-rule breaches and targets met (overall).</div>`;
  }

  // Anomalies (MAD-z)
  function anom(series){
    const vals = series.map(p=>p[1]).filter(v=>v!=null);
    if (!vals.length) return {count:0, rows:[]};
    const m = mean(vals)||0;
    const dev = vals.map(v=>Math.abs(v-m)).sort((a,b)=>a-b);
    const mad = dev[Math.floor(dev.length/2)] || 1e-9;
    const z = vals.map(v => (v-m)/(1.4826*mad));
    const pairs = series.filter(p=>p[1]!=null).map((p,i)=>[p[0],p[1],Math.abs(z[i]||0)]);
    const flagged = pairs.filter(p=>p[2]>=2.5);
    return {count: flagged.length, rows: flagged.sort((a,b)=>b[2]-a[2]).slice(0,10)};
  }
  const anA = anom(it), anD = anom(dai), anR = anom(rpr);
  function renderAnom(obj,label){
    if (!obj.count) return "<div class='mut small'>No strong anomalies (|z| ≥ 2.5).</div>";
    return "<table><thead><tr><th>Iter</th><th>"+label+"</th><th>|z|</th></tr></thead><tbody>"+obj.rows.map(r=>`<tr><td>${r[0]}</td><td>${fmt(r[1])}</td><td>${fmt(r[2])}</td></tr>`).join("")+"</tbody></table>";
  }
  section("anom-accept").innerHTML = renderAnom(anA, "Acceptance %");
  section("anom-dai").innerHTML    = renderAnom(anD, "DAI");
  section("anom-rpr").innerHTML    = renderAnom(anR, "RPR");

  // Δ Since Previous Run
  if (CERB.data.iterations_prev && CERB.data.iterations_prev.length) {
    const prev = CERB.data.iterations_prev; const lastRec = x => (x && x.length? x[x.length-1]: null);
    const DAIp = lastRec(prev)?.DAI_score; const DAIc = de;
    const RPRp = lastRec(prev)?.RPR_percent; const RPRc = re;
    const ACCp = lastRec(prev)?.resolutions_accepted; const ACCc = D.iterations?.length ? D.iterations[D.iterations.length-1]?.resolutions_accepted : null;
    const ATTp = lastRec(prev)?.resolutions_attempted; const ATTc = D.iterations?.length ? D.iterations[D.iterations.length-1]?.resolutions_attempted : null;
    const row = (lbl, pv, cv) => (pv==null || cv==null) ? "" : `<div><b>${lbl}</b> ${fmt(pv)} → ${fmt(cv)} <span class='mut'>(${(cv-pv>=0?'+':'')}${fmt(cv-pv)})</span></div>`;
    section("delta-panel").innerHTML = "<div class='kv'>" + [row("DAI",DAIp,DAIc), row("RPR",RPRp,RPRc), row("Accepted",ACCp,ACCc), row("Attempts",ATTp,ATTc)].join("") + "</div>";
  } else { section("delta-panel").innerHTML = "<div class='mut small'>No previous run found.</div>"; }

  // Top Risks
  if (CERB.data.findings && CERB.data.findings.length) {
    const rows = CERB.data.findings.slice(0,8).map(r=>`<tr><td>${fmt(r.iter)}</td><td>${fmt(r.severity)}</td><td>${fmt(r.category)}</td><td>${fmt(r.claim_id)}</td><td>${fmt(r.analysis)}</td><td>${fmt(r.schedule)}</td><td>${fmt(r.action)}</td></tr>`).join("");
    section("risks-table").innerHTML = "<table><thead><tr><th>Iter</th><th>Severity</th><th>Category</th><th>Claim</th><th>Analysis</th><th>Schedule</th><th>Action</th></tr></thead><tbody>"+rows+"</tbody></table>";
  } else { section("risks-table").innerHTML = "<div class='mut small'>Provide findings.csv to populate Top Risks.</div>"; }

  // Cost
  function corrJS(a,b){
    const xs=a.map(p=>p[1]).filter(v=>v!=null), ys=b.map(p=>p[1]).filter(v=>v!=null);
    const n=Math.min(xs.length, ys.length); if (n<2) return null;
    const x=xs.slice(0,n), y=ys.slice(0,n);
    const mx=x.reduce((x,y)=>x+y,0)/n, my=y.reduce((x,y)=>x+y,0)/n;
    let num=0, dx=0, dy=0; for(let i=0;i<n;i++){ const vx=x[i]-mx, vy=y[i]-my; num+=vx*vy; dx+=vx*vx; dy+=vy*vy; }
    return (dx*dy>0)? (num/Math.sqrt(dx*dy)) : null;
  }
  section("cost-tokens").innerHTML = spark(toks, "#a78bfa");
  section("cost-wall").innerHTML   = spark(wall, "#22d3ee");
  const rTokAcc = corrJS(toks, it);
  section("cost-vs-accept").innerHTML = (rTokAcc==null) ? "<div class='mut small'>Insufficient data.</div>" : `<div class='mut small'>Correlation (tokens ↔ acceptance): ${fmt(rTokAcc)}</div>`;

  // Severity-weighted efficacy & Pareto
  if (CERB.data.findings && CERB.data.findings.length) {
    const accMap = {}; (D.iterations||[]).forEach(r => { const iter=Number(r.iter); const a=(r.resolutions_attempted? (r.resolutions_accepted||0)/r.resolutions_attempted*100 : null); accMap[iter]=a; });
    function sevWeight(s){ if (!s) return 1; const m = String(s).match(/(\d+(\.\d+)?)/); if (m) return parseFloat(m[1]); const su=String(s).toUpperCase(); if (su.includes('HIGH')) return 5; if (su.includes('MED')) return 3; if (su.includes('LOW')) return 1; return 1; }
    const cats={};
    for (const r of CERB.data.findings){
      const c = (r.category||'uncategorized');
      const w = sevWeight(r.severity);
      cats[c] = cats[c] || {w:0, eff_w:0, n:0};
      cats[c].w += w;
      const iter = Number(r.iter)||null; const a = accMap[iter]; if (a!=null) { cats[c].eff_w += w*a; }
      cats[c].n += 1;
    }
    const items = Object.keys(cats).map(k => ({category:k, w:cats[k].w, eff: (cats[k].w? cats[k].eff_w/cats[k].w : null)})).sort((a,b)=>b.w-a.w);
    const totalW = items.reduce((x,y)=>x+y.w,0)||1;
    let cum=0; const palette=["#60a5fa","#34d399","#fbbf24","#f87171","#a78bfa","#f472b6","#22d3ee"];
    const segs = items.slice(0,8).map((it,i)=>{ const perc = it.w/totalW*100; cum += perc; return `<div title='${it.category}: ${Math.round(perc)}%' style='width:${Math.max(2,Math.round(perc))}%;background:${palette[i%palette.length]};height:16px;border-radius:4px'></div>`; }).join("");
    const rows = items.slice(0,10).map(it=>`<tr><td>${it.category}</td><td>${fmt(it.w)}</td><td>${it.eff==null?'—':pct(it.eff)}</td></tr>`).join("");
    section("sev-content").innerHTML = `<div class='mut small'>Top categories by severity-weighted volume (Pareto, top 8 shown):</div>
      <div style='display:flex;gap:4px;margin:.35rem 0'>${segs}</div>
      <table style='margin-top:.35rem'><thead><tr><th>Category</th><th>Weighted Volume</th><th>Weighted Efficacy</th></tr></thead><tbody>${rows}</tbody></table>`;
  } else { section("sev-content").innerHTML = "<div class='mut small'>Provide findings.csv to enable severity-weighted analysis.</div>"; }

  // Non-regression trendline (% bad)
  if (CERB.data.retests && CERB.data.retests.length) {
    const byIter = {};
    for (const r of CERB.data.retests){
      const itn = Number(r.current_iter||r.previous_iter||0); if (!itn) continue;
      byIter[itn] = byIter[itn] || {tot:0, bad:0};
      byIter[itn].tot += 1;
      const st = String(r.status||"").toUpperCase();
      if (st==="REOPENED" || st==="REGRESSED") byIter[itn].bad += 1;
    }
    const itkeys = Object.keys(byIter).map(x=>Number(x)).sort((a,b)=>a-b);
    const series = itkeys.map(i => [i, byIter[i].tot? (byIter[i].bad/byIter[i].tot*100) : null]);
    section("retests-spark").innerHTML = spark(series, "#f472b6");
    const rr = runRules(series);
    section("retests-runrules").innerHTML = rr.reasons.length ? ("<ul class='small'>" + rr.reasons.slice(0,8).map(x=>`<li>${x}</li>`).join("") + "</ul>") : "<div class='mut small'>No run-rule signals.</div>";
  } else {
    section("retests-spark").innerHTML = "<div class='mut small'>No non-regression data</div>";
    section("retests-runrules").innerHTML = "";
  }

  // Phase transition diagnostics (4b)
  function indexSeries(series){
    const m={}; series.forEach(([i,v])=>{ if(v!=null) m[i]=v; }); return m;
  }
  const M = {acc:indexSeries(it), dai:indexSeries(dai), rpr:indexSeries(rpr)};
  function winMean(map, start, end){
    const xs=[]; for (let i=start;i<=end;i++){ if(map[i]!=null) xs.push(map[i]); }
    if (!xs.length) return null; let s=0; for (const v of xs) s+=v; return s/xs.length;
  }
  function renderTrans(N){
    if (!phases || phases.length<2){ section("phase-diag-body").innerHTML="<tr><td colspan='8' class='mut small'>Need at least two phases to compute transitions.</td></tr>"; return; }
    const rows = [];
    for (let i=1;i<phases.length;i++){
      const prev = phases[i-1], curr=phases[i];
      const tIter = curr.start;
      const preA = winMean(M.acc, Math.max(1, tIter-N), tIter-1);
      const postA= winMean(M.acc, tIter, tIter+N-1);
      const preD = winMean(M.dai, Math.max(1, tIter-N), tIter-1);
      const postD= winMean(M.dai, tIter, tIter+N-1);
      const preR = winMean(M.rpr, Math.max(1, tIter-N), tIter-1);
      const postR= winMean(M.rpr, tIter, tIter+N-1);
      const dA = (postA!=null && preA!=null)? (postA-preA) : null;
      const dD = (postD!=null && preD!=null)? (postD-preD) : null;
      const dR = (postR!=null && preR!=null)? (postR-preR) : null;
      rows.push(`<tr>
        <td>${prev.name} → ${curr.name}</td>
        <td>${tIter}</td>
        <td>${fmt(preA)}</td><td>${fmt(postA)}</td><td>${dA==null?'—':(dA>=0?'+':'')+fmt(dA)}</td>
        <td>${fmt(preD)}</td><td>${fmt(postD)}</td><td>${dD==null?'—':(dD>=0?'+':'')+fmt(dD)}</td>
        <td>${fmt(preR)}</td><td>${fmt(postR)}</td><td>${dR==null?'—':(dR>=0?'+':'')+fmt(dR)}</td>
      </tr>`);
    }
    section("phase-diag-body").innerHTML = rows.join("");
  }
  // init diagnostics with default N=10 and wire control
  const nInput = section("phase-n");
  if (nInput){ nInput.addEventListener("input", e=>{ const v=parseInt(e.target.value||"10",10); section("phase-n-val").textContent=v; renderTrans(Math.max(1,Math.min(100,v))); }); section("phase-n-val").textContent=nInput.value; renderTrans(parseInt(nInput.value,10)); }

  // Raw-data tabs (4a)
  renderTable("tbl-iterations", CERB.data.iterations);
  renderTable("tbl-compliance", CERB.data.compliance);
  renderTable("tbl-findings", CERB.data.findings);
  renderTable("tbl-retests", CERB.data.retests);
  renderTable("tbl-phases", CERB.data.phases);
  renderTable("tbl-cats", CERB.data.category_counts);
  renderJSON("json-targets", CERB.data.targets);
  renderJSON("json-metrics", CERB.data.metrics);
  renderJSON("json-signals", CERB.data.signals);
  renderJSON("json-models", CERB.data.models);

// --- Build ANALYSIS_EXPORT snapshot for Explain buttons ---
function _arr(vals){ return vals.map(p=>p[1]).filter(v=>v!=null); }
function _mean(vals){ const xs=_arr(vals); return xs.length? xs.reduce((a,b)=>a+b,0)/xs.length : null; }
function _last(vals){ return vals.length? vals[vals.length-1][1] : null; }
function _breaches(vals){ return shewhart(vals).breaches||0; }

window.ANALYSIS_EXPORT = (function(){
  const D = CERB.data||{};
  const it = (D.iterations||[]).map(r => [Number(r.iter), r.Acceptance ?? ( (r.resolutions_attempted? (r.resolutions_accepted||0)/r.resolutions_attempted*100 : null) ) ]);
  const dai = (D.iterations||[]).map(r => [Number(r.iter), r.DAI_score!=null? Number(r.DAI_score): null]);
  const rpr = (D.iterations||[]).map(r => [Number(r.iter), r.RPR_percent!=null? Number(r.RPR_percent): null]);
  const toks = (D.iterations||[]).map(r => [Number(r.iter), (r.tokens_in_iter||0) + (r.tokens_out_iter||0) || null]);

  const ewA = ewma(it), ewD = ewma(dai), ewR = ewma(rpr);
  const gate = document.getElementById('gate-banner')?.innerText || "";
  const heat = document.getElementById('heatbar')?.innerText || "";
  const delta = document.getElementById('delta-panel')?.innerText || "";
  const costs = document.getElementById('cost-vs-accept')?.innerText || "";
  const retests = document.getElementById('retests-summary')?.innerText || "";
  const sev = document.getElementById('sev-content')?.innerText || "";

  function corr(a,b){
    const xs=a.map(p=>p[1]).filter(v=>v!=null), ys=b.map(p=>p[1]).filter(v=>v!=null);
    const n=Math.min(xs.length, ys.length); if (n<2) return null;
    const x=xs.slice(0,n), y=ys.slice(0,n);
    const mx=x.reduce((x,y)=>x+y,0)/n, my=y.reduce((x,y)=>x+y,0)/n;
    let num=0, dx=0, dy=0; for(let i=0;i<n;i++){ const vx=x[i]-mx, vy=y[i]-my; num+=vx*vy; dx+=vx*vx; dy+=vy*vy; }
    return (dx*dy>0)? (num/Math.sqrt(dx*dy)) : null;
  }

  return {
    gate,
    acceptance: { mean:_mean(it), last:_last(it), breaches:_breaches(it), ewma_last:_last(ewA) },
    dai:        { mean:_mean(dai), last:_last(dai), breaches:_breaches(dai), ewma_last:_last(ewD) },
    rpr:        { mean:_mean(rpr), last:_last(rpr), breaches:_breaches(rpr), ewma_last:_last(ewR) },
    heat_top: heat,
    deltas: delta,
    costs: { text: costs, corr_tokens_accept: corr(toks, it) },
    retests: retests,
    severity: sev
  };
})();

function help(section){
  const A = window.ANALYSIS_EXPORT || {};
  const fmt = n => (n===null || n===undefined || Number.isNaN(n)) ? "—" : (typeof n === "number" ? (Math.round(n*100)/100).toString() : n);
  const pct = n => (n===null || n===undefined || Number.isNaN(n)) ? "—" : (Math.round(n*10)/10).toString() + "%";
  const text = {
    all: [
      A.gate || "",
      `Acceptance: avg ${pct(A.acceptance?.mean)}, now ${pct(A.acceptance?.last)}, EWMA ${pct(A.acceptance?.ewma_last)}. ${A.acceptance?.breaches? 'SPC breaches present.':'No SPC breaches.'}`,
      `DAI: avg ${fmt(A.dai?.mean)}, now ${fmt(A.dai?.last)}, EWMA ${fmt(A.dai?.ewma_last)}. ${A.dai?.breaches? 'SPC breaches present.':'No SPC breaches.'}`,
      `RPR: avg ${pct(A.rpr?.mean)}, now ${pct(A.rpr?.last)}, EWMA ${pct(A.rpr?.ewma_last)}. ${A.rpr?.breaches? 'SPC breaches present.':'No SPC breaches.'}`,
      A.heat_top? ('Top categories: '+A.heat_top):'',
      A.severity? ('Weighted efficacy: '+A.severity):'',
      A.deltas? ('Δ since previous: '+A.deltas):'',
      A.costs?.text? ('Costs: '+A.costs.text):'',
      A.retests? ('Non-regression: '+A.retests):''
    ].filter(Boolean).join(' ')
  }[section] || (document.querySelector('#'+section)?.innerText || 'No summary available.');
  openModal('Summary', text.replace(/\s+/g,' ').trim());
}
});

function numbers(xs){ return xs.filter(v=>v!=null && !Number.isNaN(v)); }
function linregSlope(series, win){ // series: [[x,y]...], sliding window on y vs x
  const out=[]; if (!series.length) return out;
  for (let i=0;i<series.length;i++){
    const start = Math.max(0, i - win + 1); const seg = series.slice(start, i+1).filter(p=>p[1]!=null);
    if (seg.length<2){ out.push([series[i][0], null]); continue; }
    const n = seg.length; const xs = seg.map(p=>p[0]); const ys=seg.map(p=>p[1]);
    const mx = xs.reduce((a,b)=>a+b,0)/n; const my = ys.reduce((a,b)=>a+b,0)/n;
    let num=0,dx=0; for (let k=0;k<n;k++){ const vx=xs[k]-mx; num += vx*(ys[k]-my); dx += vx*vx; }
    out.push([series[i][0], dx>0? num/dx : null]);
  }
  return out;
}
function ewmaOnly(series, alpha){ let y=null; const out=[]; for (const [x,v] of series){ if (v==null){ out.push([x,null]); continue; } y=(y==null? v : alpha*v + (1-alpha)*y); out.push([x,y]); } return out; }
function avgIn(series, start, end){ const xs=series.filter(([i,v])=>i>=start && i<=end && v!=null).map(p=>p[1]); if(!xs.length) return null; return xs.reduce((a,b)=>a+b,0)/xs.length; }
function firstSustainedAt(series, minIter, thr, sustain){
  // series is EWMA already; find first index i>=minIter with ewma[i]>=thr for sustain steps
  const arr = series.filter(p=>p[1]!=null);
  for (let i=0;i<arr.length;i++){
    const it = arr[i][0]; if (it<minIter) continue;
    let ok=true; for (let k=0;k<sustain;k++){ const j=i+k; if (j>=arr.length){ ok=false; break; } if (!(arr[j][1]>=thr)) { ok=false; break; } }
    if (ok) return it;
  }
  return null;
}
function pct(n){ return (n==null || Number.isNaN(n))? "—" : (Math.round(n*10)/10)+'%'; }

</script>
</head>
<body>
  <header>
    <div class="row" style="justify-content:space-between">
      <div>
        <h1>__TITLE__</h1>
        <div class="mut small">Generated at __NOW__ • Client-side analytics enabled • Dummy scrub applied</div>
      </div>
      <div class="row">
        <a class="btn" href="review_pack.zip" download>Download review_pack.zip</a>
        <button class="btn" onclick="help('all')">Summarize All</button>
        <button class="btn" onclick="openModal('Plain Language Key', document.getElementById('pl-key').innerHTML)">Plain Language Key</button>
        <select id="model-select" class="btn" style="padding:.45rem .5rem"><option value="">Profile: Baseline</option></select>
        <button class="btn" onclick="openModelDesigner()">Model Designer</button>
        <button class="btn" onclick="downloadModelsJson()">Export models.json</button>
        <button class="btn" onclick="window.print()">Print / Save as PDF</button>
      </div>
    </div>
  </header>
  <main>
    <section class="card">
      <h2>Summary</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div id="summary-modal" style="display:none">
        <div>Acceptance: <b id="sum-accept"></b>, Attempts <b id="sum-attempts"></b>, Accepted <b id="sum-accepted"></b>.</div>
        <div>DAI <b id="sum-dai"></b> · RPR <b id="sum-rpr"></b>.</div>
      </div>
      <div class="kv">
        <div><b>Iterations</b> <span id="sum-iters">—</span></div>
        <div><b>Findings</b> <span id="sum-findings">—</span></div>
        <div><b>Attempts</b> <span id="sum-attempts">—</span></div>
        <div><b>Accepted</b> <span id="sum-accepted">—</span></div>
        <div><b>Acceptance</b> <span class="tip" data-tip="Accepted / Attempted × 100">?</span> <span id="sum-accept">—</span></div>
      </div>
      <div class="kv" style="margin-top:.35rem">
        <div><b>DAI</b> <span class="tip" data-tip="Diagnostic Assurance Index, 0–100">?</span> <span id="sum-dai">—</span></div>
        <div><b>RPR</b> <span class="tip" data-tip="Reproducible Pass Rate, %">?</span> <span id="sum-rpr">—</span></div>
      </div>
    </section>

    <section class="card">
      <h2>Controls &amp; Gating</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div id="gate-banner"></div>
      <div class="grid">
        <div class="card"><b>Shewhart (±3σ)</b><span class="tip" data-tip="Control chart rule with 3-sigma limits; breaches imply instability.">?</span><div id="shewhart"></div></div>
        <div class="card"><b>EWMA (α=0.2)</b><span class="tip" data-tip="Exponentially weighted mean; emphasizes recent iterations.">?</span><div id="ewma"></div></div>
        <div class="card"><b>Targets by Phase</b><span class="tip" data-tip="Phase-specific goals for Acceptance, DAI, RPR; hover chips for deltas.">?</span><div id="phase-targets"></div></div>
        <div class="card"><b>Run-rule Signals</b><span class="tip" data-tip="2-of-3 beyond ±2σ, or 8-in-a-row one side of mean.">?</span><div id="runrules"></div></div>
      </div>
    </section>

    <section class="card">
      <h2>Insights</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div class="grid">
        <div class="card"><b>Acceptance Sparkline</b><span class="tip" data-tip="Per-iteration acceptance percentage.">?</span><div class="mut small">per-iteration</div><div id="spark-accept"></div></div>
        <div class="card"><b>DAI Sparkline</b><span class="tip" data-tip="Per-iteration diagnostic assurance index (0–100).">?</span><div class="mut small">per-iteration</div><div id="spark-dai"></div></div>
        <div class="card"><b>RPR Sparkline</b><span class="tip" data-tip="Per-iteration reproducible pass rate (%).">?</span><div class="mut small">per-iteration</div><div id="spark-rpr"></div></div>
        <div class="card"><b>Category Heat</b><span class="tip" data-tip="Category mix across the run.">?</span><div class="mut small">total findings by class</div><div id="heatbar"></div></div>
      </div>
    </section>

    <section class="card" id="sev-card">
      <h2>Severity-weighted Efficacy &amp; Pareto</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div id="sev-content"></div>
    </section>

    <section class="card">
      <h2>Phase Transition Diagnostics</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div class="inline-controls">Window size (iterations): <input id="phase-n" class="input" type="number" value="10" min="1" max="100" style="width:80px"/> <span class="mut small">N = <span id="phase-n-val">10</span></span></div>
      <div style="overflow:auto"><table><thead>
        <tr><th>Transition</th><th>At Iter</th>
            <th>Acc (pre)</th><th>Acc (post)</th><th>ΔAcc</th>
            <th>DAI (pre)</th><th>DAI (post)</th><th>ΔDAI</th>
            <th>RPR (pre)</th><th>RPR (post)</th><th>ΔRPR</th></tr>
      </thead><tbody id="phase-diag-body"></tbody></table></div>
    </section>

    <section class="card">
      <h2>Δ Since Previous Run</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div id="delta-panel"></div>
    </section>

    <section class="card">
      <h2>Top Risks</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <p class="mut small">Provide <code>findings.csv</code> for real data.</p>
      <div id="risks-table"></div>
      <div style="margin-top:.5rem"><span id="dl-find"></span></div>
    </section>

    <section class="card">
      <h2>Cost &amp; Efficiency</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div class="grid">
        <div class="card"><b>Cost per Iteration (tokens)</b><span class="tip" data-tip="tokens_in_iter + tokens_out_iter">?</span><div id="cost-tokens"></div></div>
        <div class="card"><b>Wall Time per Iteration (ms)</b><span class="tip" data-tip="wall_ms_iter (elapsed time per iteration)">?</span><div id="cost-wall"></div></div>
        <div class="card"><b>Cost vs Acceptance</b><span class="tip" data-tip="Correlation between tokens and acceptance (−1 to +1).">?</span><div id="cost-vs-accept"></div></div>
      </div>
    </section>

    
    <section class="card" id="model-card">
      <h2>Model Scorecard</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div class="kv"><div><b>Active profile</b> <span id="model-name">Baseline</span></div>
      <div><b>Overall score</b> <span id="model-score">—</span></div></div>
      <div style="margin-top:.5rem" id="model-breakdown"></div>
    </section>

    <section class="card" id="derived-card">
      <h2>Derived Features</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div id="derived-content"></div>
    </section>

    <section class="card" id="resolve-card">
      <h2>Antithesis Resolution</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div id="resolve-content"></div>
    </section>
    <section class="card">
      <h2>Raw Data</h2>
      <div class="tabs">
        <div class="tab-links">
          <a class="active" onclick="showTab('tab-iter', this)">iterations.csv</a>
          <a onclick="showTab('tab-comp', this)">compliance.csv</a>
          <a onclick="showTab('tab-find', this)">findings.csv</a>
          <a onclick="showTab('tab-retests', this)">retests.csv</a>
          <a onclick="showTab('tab-phases', this)">phases.csv</a>
          <a onclick="showTab('tab-cats', this)">category_counts.csv</a>
          <a onclick="showTab('tab-targets', this)">targets.json</a>
          <a onclick="showTab('tab-metrics', this)">metrics.json</a>
          <a onclick="showTab('tab-signals', this)">signals.json</a>
          <a onclick="showTab('tab-models', this)">models.json</a>
        </div>
        <div id="tab-iter" class="tab active"><div id="tbl-iterations"></div></div>
        <div id="tab-comp" class="tab"><div id="tbl-compliance"></div></div>
        <div id="tab-find" class="tab"><div id="tbl-findings"></div></div>
        <div id="tab-retests" class="tab"><div id="tbl-retests"></div></div>
        <div id="tab-phases" class="tab"><div id="tbl-phases"></div></div>
        <div id="tab-cats" class="tab"><div id="tbl-cats"></div></div>
        <div id="tab-targets" class="tab"><div id="json-targets"></div></div>
        <div id="tab-metrics" class="tab"><div id="json-metrics"></div></div>
        <div id="tab-signals" class="tab"><div id="json-signals"></div></div>
        <div id="tab-models" class="tab"><div id="json-models"></div></div>
      </div>
    </section>

    <section id="retests-card" class="card">
      <h2>Non-Regression</h2>
      <div class="helpbar"><button class="help-btn" onclick="help('all')">Explain</button></div>
      <div id="retests-summary"></div>
      <div style="margin:.35rem 0"><b>Trend of Reopened/Regressed (%)</b></div>
      <div id="retests-spark"></div>
      <div style="margin-top:.35rem"><b>Run-rule Signals</b></div>
      <div id="retests-runrules"></div>
      <div id="retests-table" style="margin-top:.5rem"></div>
    </section>

    <section id="metrics-card" class="card">
      <h2>Run Metrics</h2>
      <div id="metrics"></div>
    </section>

    <section id="signals-card" class="card">
      <h2>Signals</h2>
      <div id="signals"></div>
    </section>

    <!-- Plain Language Key -->
    <template id="pl-key">
      <div class="key">
        <dl>
          <dt>Acceptance (%)</dt><dd>Percent of attempted resolutions that were accepted in each iteration.</dd>
          <dt>DAI</dt><dd>Diagnostic Assurance Index (0–100): strength of evidence behind conclusions.</dd>
          <dt>RPR (%)</dt><dd>Reproducible Pass Rate: repeat-pass frequency.</dd>
          <dt>Shewhart / SPC</dt><dd>Control limits (±3σ). Breaches indicate instability.</dd>
          <dt>Run-rules</dt><dd>Extra SPC checks (e.g., two of three beyond ±2σ; eight on one side).</dd>
          <dt>EWMA</dt><dd>Smooth trend emphasizing recent data.</dd>
          <dt>Phase Targets</dt><dd>Per-phase goals for Acceptance, DAI, RPR. Hover chips to see deltas.</dd>
          <dt>Phase Diagnostics</dt><dd>Compares N iterations before/after a phase switch to see if performance improved.</dd>
          <dt>Category Heat</dt><dd>Which categories occur most often.</dd>
          <dt>Severity-weighted Efficacy</dt><dd>Weights categories by severity and estimates efficacy using per-iteration acceptance.</dd>
          <dt>Δ Since Previous</dt><dd>Metric changes vs previous run.</dd>
          <dt>Non-Regression</dt><dd>Re-test outcomes of prior issues; spark shows % reopened/regressed.</dd>
          <dt>Costs</dt><dd>Tokens/time per iteration; correlation shows effectiveness of spend.</dd>
          <dt>Raw Data</dt><dd>Inline tables and prettified JSON with filtering and copy.</dd>
        </dl>
      </div>
    </template>

    <!-- Modal -->
    <div id="modal" class="modal" onclick="if(event.target.id==='modal'){closeModal()}">
      <div class="panel">
        <div class="title"><span id="modal-title">Summary</span><span class="close" onclick="closeModal()">✕</span></div>
        <div id="modal-body" class="small"></div>
      </div>
    </div>

    <script id="cerb-embed" type="application/json">__EMBED_JSON__
function numbers(xs){ return xs.filter(v=>v!=null && !Number.isNaN(v)); }
function linregSlope(series, win){ // series: [[x,y]...], sliding window on y vs x
  const out=[]; if (!series.length) return out;
  for (let i=0;i<series.length;i++){
    const start = Math.max(0, i - win + 1); const seg = series.slice(start, i+1).filter(p=>p[1]!=null);
    if (seg.length<2){ out.push([series[i][0], null]); continue; }
    const n = seg.length; const xs = seg.map(p=>p[0]); const ys=seg.map(p=>p[1]);
    const mx = xs.reduce((a,b)=>a+b,0)/n; const my = ys.reduce((a,b)=>a+b,0)/n;
    let num=0,dx=0; for (let k=0;k<n;k++){ const vx=xs[k]-mx; num += vx*(ys[k]-my); dx += vx*vx; }
    out.push([series[i][0], dx>0? num/dx : null]);
  }
  return out;
}
function ewmaOnly(series, alpha){ let y=null; const out=[]; for (const [x,v] of series){ if (v==null){ out.push([x,null]); continue; } y=(y==null? v : alpha*v + (1-alpha)*y); out.push([x,y]); } return out; }
function avgIn(series, start, end){ const xs=series.filter(([i,v])=>i>=start && i<=end && v!=null).map(p=>p[1]); if(!xs.length) return null; return xs.reduce((a,b)=>a+b,0)/xs.length; }
function firstSustainedAt(series, minIter, thr, sustain){
  // series is EWMA already; find first index i>=minIter with ewma[i]>=thr for sustain steps
  const arr = series.filter(p=>p[1]!=null);
  for (let i=0;i<arr.length;i++){
    const it = arr[i][0]; if (it<minIter) continue;
    let ok=true; for (let k=0;k<sustain;k++){ const j=i+k; if (j>=arr.length){ ok=false; break; } if (!(arr[j][1]>=thr)) { ok=false; break; } }
    if (ok) return it;
  }
  return null;
}
function pct(n){ return (n==null || Number.isNaN(n))? "—" : (Math.round(n*10)/10)+'%'; }

</script>
    <script>try { window.CERB = JSON.parse(document.getElementById('cerb-embed').textContent); } catch(e){ console.error(e); }
function numbers(xs){ return xs.filter(v=>v!=null && !Number.isNaN(v)); }
function linregSlope(series, win){ // series: [[x,y]...], sliding window on y vs x
  const out=[]; if (!series.length) return out;
  for (let i=0;i<series.length;i++){
    const start = Math.max(0, i - win + 1); const seg = series.slice(start, i+1).filter(p=>p[1]!=null);
    if (seg.length<2){ out.push([series[i][0], null]); continue; }
    const n = seg.length; const xs = seg.map(p=>p[0]); const ys=seg.map(p=>p[1]);
    const mx = xs.reduce((a,b)=>a+b,0)/n; const my = ys.reduce((a,b)=>a+b,0)/n;
    let num=0,dx=0; for (let k=0;k<n;k++){ const vx=xs[k]-mx; num += vx*(ys[k]-my); dx += vx*vx; }
    out.push([series[i][0], dx>0? num/dx : null]);
  }
  return out;
}
function ewmaOnly(series, alpha){ let y=null; const out=[]; for (const [x,v] of series){ if (v==null){ out.push([x,null]); continue; } y=(y==null? v : alpha*v + (1-alpha)*y); out.push([x,y]); } return out; }
function avgIn(series, start, end){ const xs=series.filter(([i,v])=>i>=start && i<=end && v!=null).map(p=>p[1]); if(!xs.length) return null; return xs.reduce((a,b)=>a+b,0)/xs.length; }
function firstSustainedAt(series, minIter, thr, sustain){
  // series is EWMA already; find first index i>=minIter with ewma[i]>=thr for sustain steps
  const arr = series.filter(p=>p[1]!=null);
  for (let i=0;i<arr.length;i++){
    const it = arr[i][0]; if (it<minIter) continue;
    let ok=true; for (let k=0;k<sustain;k++){ const j=i+k; if (j>=arr.length){ ok=false; break; } if (!(arr[j][1]>=thr)) { ok=false; break; } }
    if (ok) return it;
  }
  return null;
}
function pct(n){ return (n==null || Number.isNaN(n))? "—" : (Math.round(n*10)/10)+'%'; }

</script>
  </main>
</body>
</html>""")

    html = tpl.replace('__TITLE__', title).replace('__NOW__', now).replace('__EMBED_JSON__', json.dumps(embed_json, ensure_ascii=False))
    out_html = os.path.join(output_dir, "index.html")
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(html)

    # --- 4c: analysis.json + review_pack.zip
    analysis = compute_analysis({
        "generated_at": now,
        **embed_json["data"]
    })
    with open(os.path.join(output_dir, "analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2)

    # Create review pack zip with available artifacts
    zip_path = os.path.join(output_dir, "review_pack.zip")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        # Always include the HTML and analysis.json
        z.write(out_html, arcname="index.html")
        z.write(os.path.join(output_dir, "analysis.json"), arcname="analysis.json")
        # Optional artifacts
        for k, p in paths.items():
            if os.path.exists(p):
                z.write(p, arcname=os.path.basename(p))

    return out_html
