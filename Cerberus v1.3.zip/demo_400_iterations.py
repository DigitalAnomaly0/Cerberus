
# demo_400_iterations.py - Self-contained demo run for Cerberus v1.3
import os, json, math, random, csv, statistics
from datetime import datetime, timezone

random.seed(1337)
out = os.environ.get("CERB_OUTPUT_DIR","output")
os.makedirs(out, exist_ok=True)

rows = []
for i in range(1, 401):
    if i <= 300:
        ant, seed, synth = 0.70, 0.20, 0.10
    elif i <= 350:
        ant, seed, synth = 0.60, 0.30, 0.10
    elif i <= 380:
        ant, seed, synth = 0.50, 0.40, 0.10
    else:
        ant, seed, synth = 0.40, 0.50, 0.10
    findings = random.randint(2, 2+int(7*ant))
    attempts = max(0, int(round(findings*(0.30 + 0.9*seed))))
    base_acc = 0.25 + 0.5*seed + 0.15*(i/400.0)
    accepted = sum(1 for _ in range(attempts) if random.random() < min(max(base_acc,0),0.98))
    dai = max(0, min(100, 70 + 30*(i/400.0) + random.gauss(0, 2)))
    rpr = max(0, min(100, 90 + 10*(i/400.0) + random.gauss(0, 1.5)))
    rows.append([i, ant, seed, synth, findings, attempts, accepted, round(dai,2), round(rpr,2)])

# Write CSV
csv_path = os.path.join(out, "iterations.csv")
with open(csv_path,"w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["iter","antithesis","seeder","synthesis","findings","res_attempted","res_accepted","DAI","RPR"])
    w.writerows(rows)

# Minimal HTML
html = f\"\"\"<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cerberus v1.3 Demo Report</title>
<style>body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:20px}}.card{{border:1px solid #e5e7eb;border-radius:14px;padding:16px;margin-bottom:12px}}</style>
</head><body>
<h1>Cerberus v1.3 — Demo Report</h1>
<div class="card"><p>Iterations: 400 (antithesis-heavy → seeder-heavier in final 20)</p>
<p>Artifacts: <a href="iterations.csv">iterations.csv</a></p></div>
</body></html>\"\"\"
with open(os.path.join(out, "index.html"),"w",encoding="utf-8") as f:
    f.write(html)
print("Demo completed. Outputs in", out)
