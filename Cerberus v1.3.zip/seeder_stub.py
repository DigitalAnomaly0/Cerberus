#!/usr/bin/env python3

import csv, argparse, random, sys, pathlib, time

DUMMY_SOURCES = [
    ("Program take-up and admin burden: randomized reminder letters", "https://example.org/paper/reminder-letters", "Eligible recipients increased claims by 8–12% after burden reduction.", "study"),
    ("Legibility & trust in public dashboards", "https://example.org/report/trust-dashboards", "Transparency improvements correlated with +6 pt trust gains.", "report"),
    ("Privacy breach case study (linkage attack)", "https://example.org/case/privacy-linkage", "Auxiliary datasets enabled re-identification of aggregated records.", "case"),
    ("Ledger auditability pilot", "https://example.org/pilot/ledger-audit", "Tamper-evident logs reduced inconsistent entries by 90%.", "pilot"),
    ("Backstop automation outage postmortem", "https://example.org/postmortem/backstop-outage", "Delayed trigger due to stale upstream feeds; fixes deployed.", "postmortem"),
]

OUT_COLUMNS = ["DAM_ID","Counter_Type","Source_Title","Source_URL","Snippet","Evidence_Type","Quality_Score"]

def main():
    ap = argparse.ArgumentParser(description="Seeder resolver (DUMMY) — turns ANTITHESIS_SEED_TASKS.csv into ANTITHESIS_SEEDED_EXAMPLES.csv")
    ap.add_argument("--in", dest="inp", default="ANTITHESIS_SEED_TASKS.csv", help="Path to ANTITHESIS_SEED_TASKS.csv")
    ap.add_argument("--out", dest="out", default="ANTITHESIS_SEEDED_EXAMPLES.csv", help="Path to write seeded examples CSV")
    ap.add_argument("--seed", type=int, default=777, help="Deterministic RNG seed")
    args = ap.parse_args()

    path_in = pathlib.Path(args.inp)
    if not path_in.exists():
        print(f"[error] Input not found: {path_in}", file=sys.stderr)
        return 2

    random.seed(args.seed)
    rows = []
    with path_in.open(newline="", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        needed = {"DAM_ID","Counter_Type","Claim_Short","Query_1","Query_2"}
        missing = needed - set(rdr.fieldnames or [])
        if missing:
            print(f"[error] Missing columns: {', '.join(sorted(missing))}", file=sys.stderr)
            return 3
        for r in rdr:
            cid = (r.get("DAM_ID") or "").strip()
            ctype = (r.get("Counter_Type") or "").strip()
            title, url, snip, etype = random.choice(DUMMY_SOURCES)
            rows.append({
                "DAM_ID": cid,
                "Counter_Type": ctype,
                "Source_Title": f"DUMMY: {title}",
                "Source_URL": url,
                "Snippet": snip,
                "Evidence_Type": etype,
                "Quality_Score": round(random.uniform(0.6, 0.95), 2),
            })

    path_out = pathlib.Path(args.out)
    with path_out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=OUT_COLUMNS)
        w.writeheader(); w.writerows(rows)

    print(f"[ok] Wrote {len(rows)} rows to {path_out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
