#!/usr/bin/env python3
import os, re, json, sys, zipfile
from pathlib import Path

PATTERNS={
  "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
  "phone": r"\b(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}\b",
  "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
  "street": r"\b\d{1,6}\s+(?:[A-Za-z0-9'\.\-]+\s){1,5}(?:Street|St\.|Avenue|Ave\.|Road|Rd\.|Boulevard|Blvd\.|Lane|Ln\.|Drive|Dr\.|Court|Ct\.|Way)\b",
}

IGNORE_DIRS={".git",".venv","node_modules","__pycache__"}

def is_text(path):
    try:
        with open(path, "rb") as fh:
            chunk = fh.read(2048)
        return b"\x00" not in chunk
    except Exception:
        return False

def scan_text(text):
    findings=[]
    for k,pat in PATTERNS.items():
        for m in re.finditer(pat, text, flags=re.I):
            red = re.sub(r'.','*', m.group(0))
            findings.append({"type":k,"match":red})
    return findings

def scan_docx(path):
    # Light-weight: read word/document.xml from the zip
    try:
        with zipfile.ZipFile(path,"r") as z:
            with z.open("word/document.xml") as fh:
                content = fh.read().decode("utf-8","ignore")
        content = re.sub(r"<[^>]+>"," ", content)
        return scan_text(content)
    except Exception:
        return []

def main(root):
    results=[]
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]
        for name in filenames:
            fp = os.path.join(dirpath,name)
            try:
                if name.lower().endswith(".docx"):
                    fd = scan_docx(fp)
                elif name.lower().endswith((".txt",".md",".json",".yaml",".yml",".csv",".tsv",".xml",".html")):
                    if is_text(fp):
                        with open(fp,"r",encoding="utf-8",errors="ignore") as fh:
                            txt=fh.read()
                        fd = scan_text(txt)
                    else:
                        fd = []
                else:
                    fd = []
                if fd:
                    results.append({"file":fp, "findings":fd[:10]})
            except Exception:
                pass
    out = {"root":root, "hits":results}
    print(json.dumps(out, indent=2))

if __name__=="__main__":
    root = sys.argv[1] if len(sys.argv)>1 else "/mnt/data"
    main(root)
