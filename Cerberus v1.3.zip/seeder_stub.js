#!/usr/bin/env node
/**
 * Seeder resolver (DUMMY) — Node CLI
 * Usage: node seeder_stub.js --in ANTITHESIS_SEED_TASKS.csv --out ANTITHESIS_SEEDED_EXAMPLES.csv --seed 777
 */

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
function arg(name, def){ const i=args.indexOf(name); return i>=0 ? args[i+1] : def; }
const INP = arg('--in', 'ANTITHESIS_SEED_TASKS.csv');
const OUT = arg('--out', 'ANTITHESIS_SEEDED_EXAMPLES.csv');
const SEED = parseInt(arg('--seed','777'),10);

function mulberry32(a){ return function(){ let t = a += 0x6D2B79F5; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; } }
const rnd = mulberry32(isNaN(SEED)?777:SEED);

const DUMMY_SOURCES = [
  ["Program take-up and admin burden: randomized reminder letters", "https://example.org/paper/reminder-letters", "Eligible recipients increased claims by 8–12% after burden reduction.", "study"],
  ["Legibility & trust in public dashboards", "https://example.org/report/trust-dashboards", "Transparency improvements correlated with +6 pt trust gains.", "report"],
  ["Privacy breach case study (linkage attack)", "https://example.org/case/privacy-linkage", "Auxiliary datasets enabled re-identification of aggregated records.", "case"],
  ["Ledger auditability pilot", "https://example.org/pilot/ledger-audit", "Tamper-evident logs reduced inconsistent entries by 90%.", "pilot"],
  ["Backstop automation outage postmortem", "https://example.org/postmortem/backstop-outage", "Delayed trigger due to stale upstream feeds; fixes deployed.", "postmortem"],
];

function pick(arr){ return arr[Math.floor(rnd()*arr.length)] }

if(!fs.existsSync(INP)){ console.error("[error] Input not found:", INP); process.exit(2); }
const text = fs.readFileSync(INP, "utf8");
const lines = text.replace(/\r/g,"").split("\n").filter(x=>x.trim().length);
const head = lines[0].split(",");
const need = new Set(["DAM_ID","Counter_Type","Claim_Short","Query_1","Query_2"]);
const miss = [...need].filter(c=>!head.includes(c));
if(miss.length){ console.error("[error] Missing columns:", miss.join(", ")); process.exit(3); }

const rows = [];
for(let i=1;i<lines.length;i++){
  const cols = lines[i].split(",");
  const rec = Object.fromEntries(head.map((h,idx)=>[h, cols[idx]||""]));
  const cid = (rec.DAM_ID||"").trim();
  const ctype = (rec.Counter_Type||"").trim();
  const [title, url, snip, etype] = pick(DUMMY_SOURCES);
  rows.push({ DAM_ID: cid, Counter_Type: ctype, Source_Title: "DUMMY: "+title, Source_URL: url, Snippet: snip, Evidence_Type: etype, Quality_Score: (0.6 + rnd()*0.35).toFixed(2) });
}

const outHead = ["DAM_ID","Counter_Type","Source_Title","Source_URL","Snippet","Evidence_Type","Quality_Score"];
const out = [outHead.join(",")].concat(rows.map(r=> outHead.map(k=>(r[k]||"").toString().replace(/"/g,'""')).map(v=> `"${v}"`).join(","))).join("\n");
fs.writeFileSync(OUT, out, "utf8");
console.log("[ok] Wrote", rows.length, "rows to", OUT);
