
# run.py - Cerberus v1.3 wrapper entrypoint (applies enforcement + calls engine core or demo)
import os, sys
from guard_bootstrap import apply_governor_env, post_run_enforce
from emit_report import generate as emit_generate

def _has_core():
    try:
        import run_core_v12 as core
        return True
    except Exception:
        return False

def main():
    apply_governor_env()
    out = os.environ.setdefault("CERB_OUTPUT_DIR","output")
    os.makedirs(out, exist_ok=True)
    ran = False
    # Prefer the v1.2 core if present
    try:
        import run_core_v12 as core
        if hasattr(core, "main"):
            core.main()
            ran = True
        elif hasattr(core, "run"):
            core.run()
            ran = True
    except Exception as e:
        print("Core engine unavailable or failed:", e)
    if not ran:
        # Fallback: demo mode
        os.environ["DEMO_MODE"] = "1"
        import demo_400_iterations as demo
        demo

    # Post-run enforcement (PII ZERO + fail-closed)
    try:
            emit_generate(out, title='Cerberus v1.3 — Run Report')
        except Exception as _e:
            print('Emitter failed:', _e)
        report = post_run_enforce(out)
    print("Enforcement report:", report)

if __name__ == "__main__":
    main()
