# Cerberus v1.2.1 — Dummy Data Pack (Wired Antithesis→Seeder)
Build: 20250927T165918Z

This zip contains ONLY DUMMY ARTIFACTS for wiring, demonstration, and UI verification.

## Open the single-file dashboard
- `cerberus-iteration-dashboard.html` — drop in the same folder and open. It auto-loads everything it finds.

## Files included
- ATTESTATION.v3.json
- COVERAGE.v3.json
- LOOP_ITERATIONS.v3.json (+ `dai_v3_*.png` fallbacks)
- DAM_MASTER.v3.csv
- ANTITHESIS_TABLE.v3.csv
- ANTITHESIS_SEED_TASKS.csv (generated from Antithesis → Seeder handshake)
- ANTITHESIS_SEEDED_EXAMPLES.csv (DUMMY resolver output with placeholder sources)
- PIPELINE_v1_2_1.json (loop spec)
- view-*.html micro-dashboards (per-output viewers)

## Notes
- Use these as templates. Replace DUMMY files with real artifacts in production.
- The Seeder resolver here is illustrative only — it produces placeholder sources with example.org links.


## v1.2.2 Additions
- **seeder_stub.py** (Python CLI) — reads `ANTITHESIS_SEED_TASKS.csv`, writes `ANTITHESIS_SEEDED_EXAMPLES.csv` (dummy sources).
  - Usage: `python seeder_stub.py --in ANTITHESIS_SEED_TASKS.csv --out ANTITHESIS_SEEDED_EXAMPLES.csv --seed 777`
- **seeder_stub.js** (Node CLI) — same as above for Node environments.
  - Usage: `node seeder_stub.js --in ANTITHESIS_SEED_TASKS.csv --out ANTITHESIS_SEEDED_EXAMPLES.csv --seed 777`
- **seeder-resolver-demo.html** — browser drag/drop demo that turns the tasks CSV into seeded examples (dummy).
- **validate_artifacts.py** — quick contract check for all artifacts; exits non-zero if anything is missing or malformed.
  - Usage: `python validate_artifacts.py`

