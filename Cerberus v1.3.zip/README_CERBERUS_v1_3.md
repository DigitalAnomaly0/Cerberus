
# Cerberus v1.3 (Integrated) — Build 20250927T205356Z

This package merges **Cerberus v1.2 (engine)** with the **v1.3 enforcement layer** (PII‑ZERO, fail‑closed, strict synthetic).

## How to run
- **Default**: `python run.py`  
  - If the v1.2 core was detected, the wrapper calls it as `run_core_v12`.  
  - Otherwise it runs the **built‑in demo** (400 iterations: antithesis‑heavy → seed‑heavier final band).

Artifacts are written to `./output/`:
- `index.html` (demo) or your engine’s artifacts
- `iterations.csv` (demo)
- `_enforcement_report.json` (post‑run PII scan & redaction log)

## Enforcement
- **Fail‑closed** and **PII‑ZERO** gates are enabled via `governor_policy.yaml` and `guard_config.yaml`.
- The wrapper runs a **post‑run enforcement** step to redact any PII‑like content in text artifacts and will fail with a non‑zero exit code if violations persist.

## Environment toggles
- `CERB_OUTPUT_DIR` (default `output/`)
- `CERB_FAIL_CLOSED` (default `1`)
- `CERB_STRICT_SYNTHETIC` (default `1`)
- `CERB_PII_ZERO_GATE` (default `1`)

## Notes
- Original v1.2 entrypoint preserved as **run_core_v12.py** (if `run.py` existed).
- Guard files placed under root and `guard/` for clarity.
- This build is offline‑ready; no network fetch needed.
