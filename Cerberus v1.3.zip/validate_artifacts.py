
#!/usr/bin/env python3
import json, csv, sys, pathlib

EXPECTED = {
  "ATTESTATION.v3.json": {"keys": ["scores_final","coverage"]},
  "COVERAGE.v3.json": {"keys": ["claims_total","seed_linkage_rate"]},
  "LOOP_ITERATIONS.v3.json": {"is_list": True, "list_keys": ["iter","D","A","I"]},
  "DAM_MASTER.v3.csv": {"cols": ["DAM_ID","DAM_Text"]},
  "ANTITHESIS_TABLE.v3.csv": {"cols": ["DAM_ID","Counter_Type","Counter_Prompt"]},
  "ANTITHESIS_SEED_TASKS.csv": {"optional": True, "cols": ["DAM_ID","Counter_Type","Query_1","Query_2"]},
  "ANTITHESIS_SEEDED_EXAMPLES.csv": {"optional": True, "cols": ["DAM_ID","Counter_Type","Source_Title","Source_URL","Snippet"]},
}

def check_json(path, spec):
  data = json.loads(path.read_text(encoding="utf-8"))
  if spec.get("is_list"):
    if not isinstance(data, list) or not data:
      return f"{path.name}: expected non-empty JSON array"
    miss = [k for k in spec["list_keys"] if k not in data[0]]
    if miss: return f"{path.name}: missing keys in first element: {', '.join(miss)}"
  else:
    miss = [k for k in spec["keys"] if k not in data]
    if miss: return f"{path.name}: missing keys: {', '.join(miss)}"
  return None

def check_csv(path, spec):
  with path.open(newline="", encoding="utf-8") as f:
    rdr = csv.DictReader(f)
    miss = [c for c in spec["cols"] if c not in (rdr.fieldnames or [])]
    if miss: return f"{path.name}: missing columns: {', '.join(miss)}"
    # check at least one row
    try: next(iter(rdr))
    except StopIteration: return f"{path.name}: no data rows"
  return None

def main():
  root = pathlib.Path(".")
  errors = []
  for name, spec in EXPECTED.items():
    p = root / name
    if not p.exists():
      if spec.get("optional"): continue
      errors.append(f"{name}: not found"); continue
    if name.endswith(".json"): err = check_json(p, spec)
    else: err = check_csv(p, spec)
    if err: errors.append(err)
  if errors:
    print("[invalid]")
    for e in errors: print(" -", e)
    return 2
  print("[ok] all artifacts valid")
  return 0

if __name__ == "__main__":
  raise SystemExit(main())
